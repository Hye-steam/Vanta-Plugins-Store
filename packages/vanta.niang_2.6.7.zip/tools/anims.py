#!/usr/bin/env python3
"""Vanta娘素材处理：把网格图切成帧，或把绿幕抠成透明。

用法：
  python3 tools/anims.py slice <状态名> <网格图> <列数> <行数> [--size 512] [--key]
  python3 tools/anims.py key <状态名> [--color 00FF00]

slice 会把每格裁成正方形、可选缩放，写到 anim/<状态名>/f_00.png 起，
并自动把 anim/manifest.json 里该状态的 count 改成实际帧数。
--key 表示切完再抠掉绿幕。
"""
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
ANIM = ROOT / "anim"
MANIFEST = ANIM / "manifest.json"


def run(args):
    proc = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if proc.returncode != 0:
        raise SystemExit(f"命令失败: {' '.join(args)}\n{proc.stdout.decode('utf-8', 'ignore')[-800:]}")
    return proc.stdout.decode("utf-8", "ignore")


def probe_size(path):
    out = run(["ffprobe", "-v", "error", "-select_streams", "v:0",
               "-show_entries", "stream=width,height", "-of", "csv=p=0", str(path)])
    w, h = out.strip().split(",")[:2]
    return int(w), int(h)


def key_out(src, dst):
    # colorkey 只对近似纯色生效，相似度放宽容忍抗锯齿边缘
    run(["ffmpeg", "-y", "-v", "error", "-i", str(src),
         "-vf", "colorkey=0x00FF00:0.30:0.12,format=rgba", str(dst)])


def slice_grid(state, grid, cols, rows, size=None, do_key=False):
    grid = pathlib.Path(grid)
    if not grid.exists():
        raise SystemExit(f"找不到图片: {grid}")
    wide, high = probe_size(grid)
    cell_w = wide // cols
    cell_h = high // rows
    # 网格图常带分隔线，向内缩 1px 再去掉
    inset = 1
    out_dir = ANIM / state
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    index = 0
    for row in range(rows):
        for col in range(cols):
            x = col * cell_w + inset
            y = row * cell_h + inset
            w = cell_w - inset * 2
            h = cell_h - inset * 2
            # 取短边做正方形，保证帧之间角色不被拉伸
            side = min(w, h)
            x += (w - side) // 2
            y += (h - side) // 2
            filters = [f"crop={side}:{side}:{x}:{y}"]
            if size:
                filters.append(f"scale={size}:{size}:flags=lanczos")
            filters.append("format=rgba")
            dst = out_dir / f"f_{index:02d}.png"
            run(["ffmpeg", "-y", "-v", "error", "-i", str(grid),
                 "-vf", ",".join(filters), str(dst)])
            if do_key:
                key_out(dst, dst)
            index += 1

    update_manifest(state, index)
    print(f"已生成 {index} 帧 → {out_dir.relative_to(ROOT)}")


def key_state(state):
    out_dir = ANIM / state
    frames = sorted(out_dir.glob("f_*.png"))
    if not frames:
        raise SystemExit(f"{out_dir} 里没有帧")
    for f in frames:
        key_out(f, f)
    print(f"已抠图 {len(frames)} 帧")


def update_manifest(state, count):
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    clips = data.setdefault("clips", {})
    clip = clips.setdefault(state, {"count": 0, "fps": 10, "loop": True})
    clip["count"] = count
    MANIFEST.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def main(argv):
    if len(argv) < 2:
        raise SystemExit(__doc__)
    cmd = argv[1]
    if cmd == "slice":
        if len(argv) < 6:
            raise SystemExit("用法: anims.py slice <状态名> <网格图> <列> <行> [--size 512] [--key]")
        state, grid, cols, rows = argv[2], argv[3], int(argv[4]), int(argv[5])
        size = None
        do_key = False
        rest = argv[6:]
        i = 0
        while i < len(rest):
            if rest[i] == "--size":
                size = int(rest[i + 1]); i += 2
            elif rest[i] == "--key":
                do_key = True; i += 1
            else:
                i += 1
        slice_grid(state, grid, cols, rows, size, do_key)
    elif cmd == "key":
        if len(argv) < 3:
            raise SystemExit("用法: anims.py key <状态名>")
        key_state(argv[2])
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main(sys.argv)
