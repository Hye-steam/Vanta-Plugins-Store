#!/usr/bin/env python3
"""一次切出多个状态：网格里每格是不同状态的一张图。

用法：
  python3 tools/slice_states.py <网格图> <列> <行> --states idle,click,work,busy,success,error,drag,turn,action

按从左到右、从上到下对应 --states 的顺序。每格输出到 anim/<状态>/f_00.png，
并把 manifest 里该状态的 count 设为 1（单帧 + 程序化动作）。
"""
import json
import pathlib
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from slice_green import MANIFEST, ANIM, INSET, key_green, load_rgba, bbox  # noqa: E402


def main(argv):
    if len(argv) < 4:
        raise SystemExit(__doc__)
    grid = pathlib.Path(argv[1])
    cols, rows = int(argv[2]), int(argv[3])
    states = []
    target_h, canvas = 900, 1024
    i = 4
    while i < len(argv):
        if argv[i] == "--states":
            states = [s.strip() for s in argv[i + 1].split(",") if s.strip()]
            i += 2
        elif argv[i] == "--height":
            target_h = int(argv[i + 1]); i += 2
        elif argv[i] == "--canvas":
            canvas = int(argv[i + 1]); i += 2
        else:
            i += 1
    if not states:
        raise SystemExit("缺少 --states")

    buf, W, H = load_rgba(grid)
    cell_w, cell_h = W // cols, H // rows
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))

    index = 0
    for row in range(rows):
        for col in range(cols):
            if index >= len(states):
                break
            state = states[index]
            inner_w, inner_h = cell_w - INSET * 2, cell_h - INSET * 2
            cell = key_green(buf, col * cell_w + INSET, row * cell_h + INSET, inner_w, inner_h, W)
            box = bbox(cell, inner_w, inner_h)
            if not box:
                print(f"[warn] {state} 格子是空的，跳过")
                index += 1
                continue
            bx, by, bx2, by2 = box
            bw, bh = bx2 - bx, by2 - by
            cropped = bytearray(bw * bh * 4)
            for y in range(bh):
                s = ((by + y) * inner_w + bx) * 4
                cropped[y * bw * 4:(y + 1) * bw * 4] = cell[s:s + bw * 4]

            out_dir = ANIM / state
            out_dir.mkdir(parents=True, exist_ok=True)
            for old in out_dir.glob("f_*.png"):
                old.unlink()
            new_w = max(1, int(round(bw * target_h / bh)))
            pad_x = max(0, (canvas - new_w) // 2)
            pad_y = max(0, canvas - target_h)
            vf = (f"scale={new_w}:{target_h}:flags=lanczos,"
                  f"pad={canvas}:{canvas}:{pad_x}:{pad_y}:color=0x00000000")
            p = subprocess.run(
                ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgba",
                 "-s", f"{bw}x{bh}", "-i", "-", "-vf", vf, "-frames:v", "1",
                 str(out_dir / "f_00.png")],
                input=bytes(cropped), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if p.returncode != 0:
                raise SystemExit(p.stderr.decode("utf-8", "ignore")[-400:])
            clip = manifest["clips"].setdefault(state, {})
            clip["count"] = 1
            clip.pop("file", None)
            print(f"{state}: 内容 {bw}x{bh} → 缩放 {new_w}x{target_h}")
            index += 1

    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"完成 {index} 个状态")


if __name__ == "__main__":
    main(sys.argv)
