#!/usr/bin/env python3
"""裁掉帧四周的透明边，只保留 2% 留白。

浮层窗口固定 200×280，画面里透明边越多，角色实际渲染得越小。
按 alpha 包围盒裁剪后，角色能填满可用高度。
"""
import pathlib
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from slice_green import ANIM, bbox, load_rgba  # noqa: E402

MARGIN_RATIO = 0.02


def process(frame: pathlib.Path):
    buf, w, h = load_rgba(frame)
    box = bbox(buf, w, h)
    if not box:
        print(f"{frame}: 全透明，跳过")
        return
    bx, by, bx2, by2 = box
    margin_x = int((bx2 - bx) * MARGIN_RATIO)
    margin_y = int((by2 - by) * MARGIN_RATIO)
    x = max(0, bx - margin_x)
    y = max(0, by - margin_y)
    cw = min(w - x, bx2 - bx + margin_x * 2)
    ch = min(h - y, by2 - by + margin_y * 2)

    # 保持原格式：webp 帧必须重新编码成 webp，否则内容与扩展名不符
    is_webp = frame.suffix.lower() == ".webp"
    tmp = frame.with_name(frame.stem + ".trim" + frame.suffix)
    args = ["ffmpeg", "-y", "-v", "error", "-i", str(frame),
            "-vf", f"crop={cw}:{ch}:{x}:{y}", "-frames:v", "1"]
    if is_webp:
        args += ["-c:v", "libwebp", "-quality", "90", "-compression_level", "6"]
    args.append(str(tmp))
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise SystemExit(p.stderr.decode("utf-8", "ignore")[-300:])
    tmp.replace(frame)
    print(f"{frame.relative_to(ANIM)}: {w}x{h} → {cw}x{ch}")


def main():
    files = sorted(ANIM.glob("*/f_*.png")) + sorted(ANIM.glob("*/f_*.webp"))
    for f in files:
        process(f)
    print(f"已处理 {len(files)} 帧")


if __name__ == "__main__":
    main()
