#!/usr/bin/env python3
"""把绿幕网格切成归一化帧序列（无需 PIL）。

思路：
1. ffmpeg 把网格图解成 raw RGBA
2. Python 直接按像素做绿幕抠图（alpha=0），再做边缘去溢色
3. 逐格算内容包围盒（按行/列覆盖率过滤细白线等杂物）
4. 每格按同一目标高度缩放、底部居中对齐，消除各格角色大小不一致
5. ffmpeg 编码成 PNG（带 alpha）

用法：
  python3 tools/slice_green.py <网格图> <状态名> <列> <行> [--height 900] [--canvas 1024]
"""
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
ANIM = ROOT / "anim"
MANIFEST = ANIM / "manifest.json"

GREEN_MIN = 150      # G 通道下限
OTHER_MAX = 130      # R/B 上限
COVER_RATIO = 0.06   # 一行/列里内容像素占比低于此值视为杂物（滤掉网格线与细白条）
INSET = 8            # 每格向内缩，去掉网格分隔白线


def ffmpeg(args, stdin_bytes=None):
    proc = subprocess.run(args, input=stdin_bytes,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode != 0:
        raise SystemExit(f"ffmpeg 失败: {' '.join(args)}\n{proc.stderr.decode('utf-8','ignore')[-600:]}")
    return proc


def load_rgba(path):
    out = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(path), "-f", "rawvideo",
         "-pix_fmt", "rgba", "-"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if out.returncode != 0:
        raise SystemExit(out.stderr.decode("utf-8", "ignore")[-400:])
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "csv=p=0", str(path)],
        stdout=subprocess.PIPE).stdout.decode().strip().split(",")
    w, h = int(probe[0]), int(probe[1])
    return bytearray(out.stdout), w, h


def key_green(buf, x0, y0, cell_w, cell_h, full_w):
    """就地抠掉绿色并去溢色，返回该格的 RGBA 片段。"""
    cell = bytearray(cell_w * cell_h * 4)
    for y in range(cell_h):
        src = ((y0 + y) * full_w + x0) * 4
        dst = y * cell_w * 4
        for x in range(cell_w):
            r = buf[src]; g = buf[src + 1]; b = buf[src + 2]
            is_green = g >= GREEN_MIN and r <= OTHER_MAX and b <= OTHER_MAX
            if is_green:
                # 透明像素，RGB 也清成背景色，缩放插值时才不会带回绿边
                cell[dst] = 0; cell[dst + 1] = 0; cell[dst + 2] = 0; cell[dst + 3] = 0
            else:
                # 去溢色：绿色明显高出的像素把 G 压到 R/B 的均值附近
                if g > r + 40 and g > b + 40:
                    g = (r + b) // 2
                cell[dst] = r; cell[dst + 1] = g; cell[dst + 2] = b; cell[dst + 3] = 255
            src += 4
            dst += 4
    return cell


def bbox(cell, w, h):
    rows = [0] * h
    cols = [0] * w
    for y in range(h):
        base = y * w * 4
        for x in range(w):
            if cell[base + x * 4 + 3] > 0:
                rows[y] += 1
                cols[x] += 1
    min_row = next((y for y in range(h) if rows[y] > w * COVER_RATIO), None)
    max_row = next((y for y in range(h - 1, -1, -1) if rows[y] > w * COVER_RATIO), None)
    min_col = next((x for x in range(w) if cols[x] > h * COVER_RATIO), None)
    max_col = next((x for x in range(w - 1, -1, -1) if cols[x] > h * COVER_RATIO), None)
    if min_row is None or min_col is None:
        return None
    return min_col, min_row, max_col + 1, max_row + 1


def main(argv):
    if len(argv) < 5:
        raise SystemExit(__doc__)
    grid = pathlib.Path(argv[1])
    state = argv[2]
    cols, rows = int(argv[3]), int(argv[4])
    target_h = 900
    canvas = 1024
    rest = argv[5:]
    i = 0
    while i < len(rest):
        if rest[i] == "--height":
            target_h = int(rest[i + 1]); i += 2
        elif rest[i] == "--canvas":
            canvas = int(rest[i + 1]); i += 2
        else:
            i += 1

    buf, W, H = load_rgba(grid)
    cell_w, cell_h = W // cols, H // rows
    out_dir = ANIM / state
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("f_*.png"):
        old.unlink()

    index = 0
    for row in range(rows):
        for col in range(cols):
            inner_w = cell_w - INSET * 2
            inner_h = cell_h - INSET * 2
            cell = key_green(buf, col * cell_w + INSET, row * cell_h + INSET, inner_w, inner_h, W)
            box = bbox(cell, inner_w, inner_h)
            if not box:
                print(f"[warn] 第 {index} 格没有内容，跳过")
                index += 1
                continue
            bx, by, bx2, by2 = box
            bw, bh = bx2 - bx, by2 - by
            # 裁出包围盒的原始 RGBA
            cropped = bytearray(bw * bh * 4)
            for y in range(bh):
                s = ((by + y) * inner_w + bx) * 4
                cropped[y * bw * 4:(y + 1) * bw * 4] = cell[s:s + bw * 4]

            dst = out_dir / f"f_{index:02d}.png"
            # 统一缩放到 target_h，再底部居中放进正方形画布
            scale = target_h / bh
            new_w = max(1, int(round(bw * scale)))
            pad_x = max(0, (canvas - new_w) // 2)
            pad_y = max(0, canvas - target_h)
            vf = (f"scale={new_w}:{target_h}:flags=lanczos,"
                  f"pad={canvas}:{canvas}:{pad_x}:{pad_y}:color=0x00000000")
            p = subprocess.run(
                ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgba",
                 "-s", f"{bw}x{bh}", "-i", "-", "-vf", vf, "-frames:v", "1", str(dst)],
                input=bytes(cropped), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if p.returncode != 0:
                raise SystemExit(p.stderr.decode("utf-8", "ignore")[-400:])
            print(f"f_{index:02d}: 原内容 {bw}x{bh} → 缩放 {new_w}x{target_h}")
            index += 1

    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    clip = data["clips"].setdefault(state, {})
    clip["count"] = index
    clip.pop("file", None)
    if state == "idle" and "fps" not in clip:
        clip["fps"] = 7
    MANIFEST.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"已写入 {index} 帧 → {out_dir}，manifest.count = {index}")


if __name__ == "__main__":
    main(sys.argv)
