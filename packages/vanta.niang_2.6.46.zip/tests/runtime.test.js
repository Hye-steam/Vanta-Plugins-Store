'use strict';
const { startRuntime, ROOT } = require('./harness');
const fs = require('fs');
const path = require('path');

const manifest = fs.readFileSync(path.join(ROOT, 'anim/manifest.json'), 'utf8');
let pass = 0, fail = 0;

function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (extra ? ' → ' + extra : '')); }
}

async function scenario(name, fn) {
  console.log('\n[' + name + ']');
  const rt = startRuntime({
    files: { 'anim/manifest.json': manifest },
    onPostMessage: (p) => rt.posts.push(p)
  });
  rt.posts = [];
  try { await fn(rt); } finally { rt.close(); }
}

function lastResize(rt) {
  // 宿主只有 host.overlay.update（按 overlayId 定位）
  const list = rt.calls.filter(c => c.method === 'host.overlay.update');
  return list.length ? list[list.length - 1].params : null;
}

(async () => {
  await scenario('档位设置会清掉 widthOverride（P1）', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    const w = await rt.request('tool.invoke', 'tools.size', { width: 150 });
    check('精确宽度写入', w.widthOverride === 150, JSON.stringify(w));
    await new Promise(r => setTimeout(r, 120));
    const l = await rt.request('tool.invoke', 'tools.size', { level: 'large' });
    check('档位覆盖宽度', l.sizeLevel === 'large' && l.widthOverride === null, JSON.stringify(l));
    await new Promise(r => setTimeout(r, 120));
    const cfg = JSON.parse(rt.files['data://config.json']);
    check('配置文件里 widthOverride 已清空', cfg.widthOverride === null, JSON.stringify(cfg));
    const upd = lastResize(rt);
    check('窗口宽变大', upd && upd.width === 194, JSON.stringify(upd));
    check('带 overlayId', upd && upd.overlayId === 'ov-1', JSON.stringify(upd));
  });

  await scenario('默认档位是小', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    const create = rt.calls.filter(c => c.method === 'host.overlay.create').pop();
    check('建窗 109dp 宽', create && create.params.width === 109, JSON.stringify(create && create.params));
    const st = await rt.request('tool.invoke', 'overlay.status');
    check('默认配置 sizeLevel=small', st && st.config && st.config.sizeLevel === 'small',
      JSON.stringify(st && st.config));
  });

  await scenario('非法档位明确报错', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    const res = await rt.request('tool.invoke', 'tools.size', { level: 'huge' });
    check('返回 ok:false', res.ok === false, JSON.stringify(res));
    check('带可用值提示', /small \/ medium \/ large/.test(res.error || ''), res.error);
  });

  await scenario('旧配置迁移（清残留 widthOverride）', async (rt) => {
    rt.files['data://config.json'] = JSON.stringify({ sizeLevel: 'medium', widthOverride: 137 });
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    await new Promise(r => setTimeout(r, 200));
    const cfg = JSON.parse(rt.files['data://config.json']);
    check('widthOverride 被清空', cfg.widthOverride === null, JSON.stringify(cfg));
    check('打上 configVersion=2', cfg.configVersion === 2, String(cfg.configVersion));
    const create = rt.calls.filter(c => c.method === 'host.overlay.create').pop();
    check('建窗用 145dp', create && create.params.width === 145, JSON.stringify(create && create.params));
  });

  await scenario('并发写配置不互相覆盖', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    await Promise.all([
      rt.request('tool.invoke', 'ui.config.set', { patch: { showBubbles: false } }),
      rt.request('tool.invoke', 'ui.config.set', { patch: { bubbleMs: 3000 } })
    ]);
    await new Promise(r => setTimeout(r, 250));
    const cfg = JSON.parse(rt.files['data://config.json']);
    check('两项都保留', cfg.showBubbles === false && cfg.bubbleMs === 3000, JSON.stringify(cfg));
  });

  await scenario('runFinished 无 status 不猜成功', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunFinished', {});
    const state = rt.posts.filter(p => p.type === 'state').pop();
    check('回到 idle', state && state.state === 'idle', JSON.stringify(state));
  });

  await scenario('runFinished 有 status 正常切换', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunFinished', { status: 'error' });
    const state = rt.posts.filter(p => p.type === 'state').pop();
    check('切到 error', state && state.state === 'error', JSON.stringify(state));
  });

  await scenario('say 空文本返回错误码', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    const res = await rt.request('tool.invoke', 'tools.say', { text: '' });
    check('ok:false + EMPTY_TEXT', res.ok === false && res.code === 'EMPTY_TEXT', JSON.stringify(res));
  });

  await scenario('按状态切换窗口宽度', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    await rt.request('tool.invoke', 'tools.size', { level: 'medium' });
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunStarted', {});
    let w = lastResize(rt);
    check('work 走 628 画布 → 145dp', w && w.width === 145, JSON.stringify(w));
    await rt.request('hook.invoke', 'hooks.agentRunFinished', { status: 'success' });
    w = lastResize(rt);
    check('success 也是 628 画布', w && w.width === 145, JSON.stringify(w));
    await rt.request('tool.invoke', 'overlay.message', { payload: { type: 'state', state: 'idle' } });
    w = lastResize(rt);
    check('页面回执后收窄到 145dp', w && w.width === 145, JSON.stringify(w));
  });

  await scenario('sleep 不关浮层', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    const res = await rt.request('tool.invoke', 'tools.sleep', {});
    check('返回 state=sleep', res.state === 'sleep', JSON.stringify(res));
    check('没有调用 overlay.close', !rt.calls.some(c => c.method === 'host.overlay.close'));
  });

  await scenario('overlay.message 未知类型不报错崩溃', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    const res = await rt.request('tool.invoke', 'overlay.message', { payload: { type: 'nope' } });
    check('返回 ok:false', res.ok === false, JSON.stringify(res));
    const ok = await rt.request('tool.invoke', 'overlay.message', { payload: { type: 'ready' } });
    check('ready 正常应答', ok.ok === true, JSON.stringify(ok));
  });

  await scenario('工具步数与失败点名', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunStarted', {});
    await rt.request('hook.invoke', 'hooks.agentToolStarted', { toolName: 'bash' });
    await rt.request('hook.invoke', 'hooks.agentToolStarted', { toolName: 'readFile' });
    let says = rt.posts.filter(p => p.type === 'say').map(p => p.text);
    check('首步不带步数', says[0] === '正在跑命令', says[0]);
    check('第二步带步数', says[1] === '正在读文件 · 第 2 步', says[1]);
    await rt.request('hook.invoke', 'hooks.agentToolFinished', { toolName: 'readFile', status: 'error' });
    says = rt.posts.filter(p => p.type === 'say').map(p => p.text);
    check('失败点名到具体工具', says[says.length - 1] === '读文件失败了', says[says.length - 1]);
    await rt.request('hook.invoke', 'hooks.agentToolFinished', { toolName: 'bash', status: 'success', durationMs: 21000 });
    says = rt.posts.filter(p => p.type === 'say').map(p => p.text);
    check('慢调用报耗时', says[says.length - 1] === '完成 · 用了 21 秒', says[says.length - 1]);
  });

  await scenario('完成总结带步数与耗时', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunStarted', {});
    await rt.request('hook.invoke', 'hooks.agentToolStarted', { toolName: 'readFile' });
    await new Promise(r => setTimeout(r, 1100));
    await rt.request('hook.invoke', 'hooks.agentRunFinished', { status: 'success', toolCalls: 5 });
    const st = rt.posts.filter(p => p.type === 'state').pop();
    check('气泡含 5 步', st && /5 步/.test(st.text), JSON.stringify(st));
    check('气泡含秒数', st && /秒/.test(st.text), JSON.stringify(st));
  });

  await scenario('出错总结带错误码', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunStarted', {});
    await rt.request('hook.invoke', 'hooks.agentRunFinished', { status: 'error', errorCode: 'EMPTY' });
    const st = rt.posts.filter(p => p.type === 'state').pop();
    check('气泡含错误码', st && /EMPTY/.test(st.text), JSON.stringify(st));
  });

  await scenario('收起时不再按状态改窗口', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    await rt.request('tool.invoke', 'tools.size', { level: 'medium' });
    await rt.request('tool.invoke', 'overlay.message', { payload: { type: 'collapsed', value: true } });
    rt.posts.length = 0;
    const before = rt.calls.filter(c => c.method === 'host.overlay.update').length;
    await rt.request('hook.invoke', 'hooks.agentRunStarted', {});
    const after = rt.calls.filter(c => c.method === 'host.overlay.update').length;
    check('收起期间不发 resize', after === before, `${before} → ${after}`);
    await rt.request('tool.invoke', 'overlay.message', { payload: { type: 'collapsed', value: false } });
    const expanded = rt.calls.filter(c => c.method === 'host.overlay.update').length;
    check('展开后补一次 resize', expanded === after + 1, `${after} → ${expanded}`);
  });

  await scenario('收起状态被记住', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    await rt.request('tool.invoke', 'overlay.message', { payload: { type: 'collapsed', value: true } });
    await new Promise(r => setTimeout(r, 150));
    const cfg = JSON.parse(rt.files['data://config.json'] || '{}');
    check('配置写入 collapsed', cfg.collapsed === true, JSON.stringify(cfg).slice(0, 120));
  });

  await scenario('重启后按记住的状态补发', async (rt) => {
    rt.files['data://config.json'] = JSON.stringify({ sizeLevel: 'small', collapsed: true, configVersion: 2 });
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    await rt.request('tool.invoke', 'overlay.message', { payload: { type: 'ready' } });
    const msg = rt.posts.find(p => p.type === 'collapsed');
    check('ready 后补发 collapsed=true', msg && msg.value === true, JSON.stringify(msg));
  });

  await scenario('状态切换只保留一个可见视频', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    const posts = [];
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunStarted', {});
    await rt.request('hook.invoke', 'hooks.agentRunFinished', { status: 'success' });
    await rt.request('hook.invoke', 'hooks.agentRunStarted', {});
    const states = rt.posts.filter(p => p.type === 'state').map(p => p.state);
    check('状态按顺序切换', states.join('>') === 'work>success>work', states.join('>'));
  });

  await scenario('多会话只跟最新，其余只计数', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunStarted', { sessionId: 'A' });
    await rt.request('hook.invoke', 'hooks.agentRunStarted', { sessionId: 'B' });
    let says = rt.posts.filter(p => p.type === 'say').map(p => p.text);
    await rt.request('hook.invoke', 'hooks.agentToolStarted', { sessionId: 'A', toolName: 'bash' });
    says = rt.posts.filter(p => p.type === 'say').map(p => p.text);
    check('旧会话的工具被忽略', !says.some(t => t.includes('跑命令')), JSON.stringify(says));
    await rt.request('hook.invoke', 'hooks.agentToolStarted', { sessionId: 'B', toolName: 'bash' });
    says = rt.posts.filter(p => p.type === 'say').map(p => p.text);
    check('当前会话显示并发数', says[says.length-1] === '正在跑命令 · 还有 1 个任务', says[says.length-1]);
    await rt.request('hook.invoke', 'hooks.agentRunFinished', { sessionId: 'A', status: 'success' });
    const st = rt.posts.filter(p => p.type === 'state').pop();
    check('旧会话结束不切状态', st.state === 'work', JSON.stringify(st));
  });

  await scenario('完成时提示剩余任务数', async (rt) => {
    await rt.request('tool.invoke', 'hooks.pluginEnabled');
    rt.posts.length = 0;
    await rt.request('hook.invoke', 'hooks.agentRunStarted', { sessionId: 'A' });
    await rt.request('hook.invoke', 'hooks.agentRunStarted', { sessionId: 'B' });
    await rt.request('hook.invoke', 'hooks.agentRunFinished', { sessionId: 'B', status: 'success', toolCalls: 3 });
    const st = rt.posts.filter(p => p.type === 'state').pop();
    check('提示还有 1 个任务', st && /还有 1 个任务/.test(st.text), JSON.stringify(st));
  });

  console.log(`\n结果：${pass} 通过，${fail} 失败`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('测试异常', e); process.exit(2); });
