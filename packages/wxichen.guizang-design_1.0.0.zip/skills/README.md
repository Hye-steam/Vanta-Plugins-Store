# 技能来源

本目录由 `tools/port-skills.mjs` 从 https://github.com/op7418/dsh-guizang-design 的
DSH 插件快照生成，只保留 SKILL.md 正文（AiCode 只把正文交给模型），其余文件在 `assets/skills/` 下。
不要手改本目录的文件。

| 插件内 id | 原 skill | 上游仓库 | 固定提交 | 许可证 |
|---|---|---|---|---|
| ppt | guizang-ppt-skill | https://github.com/op7418/guizang-ppt-skill | 93d21bf4a73a851907a6eb00acbf30618236667a | AGPL-3.0 |
| social-card | guizang-social-card-skill | https://github.com/op7418/guizang-social-card-skill | 64d02d435fb092d3b403455a875e842fc8f29b8b | AGPL-3.0 |
| page | guizang-page-skill | https://github.com/op7418/guizang-pages-skill | bb39103c94c286ea8e729daf40e5ed9348ac608e | AGPL-3.0 |
| humanizer | humanizer-zh | https://github.com/op7418/Humanizer-zh | f4518a8eab97b8bfebc66a89d34320a89bef6930 | MIT |
| voice | guizang-voice（插件自有） | https://github.com/op7418/dsh-guizang-design | — | AGPL-3.0 |
