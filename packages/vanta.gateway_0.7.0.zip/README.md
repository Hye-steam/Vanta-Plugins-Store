# VantaGate 插件

把免费模型渠道汇成一个 OpenAI 兼容供应商。

## 安装

1. 确保 VantaCode 的容器已初始化（插件跑在容器内的 Node 上）
2. 设置 → AI 配置 → 插件 → 从文件安装 `vanta.gateway-0.7.0.zip`
3. 装好后「AI 供应商」会自动出现 **FreePool**，模型选择器里可选
4. **装完必须重启 VantaCode**：`app.started` 钩子只在进程启动时触发，否则网关不会监听端口
5. 插件详情页顶部会出现「插件管理 / 插件配置」两个 tab，后者是网关仪表盘

## 工作方式

插件进程常驻，在 `127.0.0.1:8888` 起一个 OpenAI 兼容服务。
宿主通过 `contributes.providers` 把它注册成普通供应商，请求打到这个本地端口。

端口可用环境变量 `VANTAGATE_PORT` 覆盖。

## 已支持的渠道

| 渠道 | 模型数 | 说明 |
|---|---|---|
| Pollinations | 4 | 匿名通道 |
| LLM7 | 9 | 匿名每日约 60 次 |
| Kilo | 13 | 免费池，推理模型需大 max_tokens |
| BlockRun | 8 | NVIDIA 托管公共池 |
| Pollinations 图片 | 4 | 免登录出图，约 1 张/40 秒 |
| OVHcloud | 3 | 公共 endpoints，无 SLA |

共 41 个模型。模型名格式为 `渠道/模型`，例如 `pollinations/openai-fast`。

## 已知限制

- 依赖容器内的 Node，容器未初始化时装上跑不起来
- VantaCode 进程被杀时插件进程也会退出（这是插件形态的固有限制，不像独立 App 能靠开机脚本常驻）
- 免费渠道都有额度闸门，429 是常态
