# 破甲核心 (vanta.armor)

VantaCode 官方插件（发布方 `vanta` / `Hye-steam`）。把 `破甲提示词通用-1`（pojiaai）做成声明式插件：
一个技能 + 一个同源子代理，不含运行时、不执行任何代码。

## 包内容

```
plugin.json          清单：声明一个技能 + 一个子代理
skills/persona.md    技能正文（frontmatter: name = persona）
agents/worker.md     子代理正文，人格与技能完全同源
```

正文与原始提示词逐字一致，只加了工具链要求的两行 frontmatter。

## 安装

- 插件商店搜「破甲核心」或 ID `vanta.armor`，点安装后启用。
- 或手动：设置 → 插件 → 右上「+」→ 选 `vanta.armor_1.0.0.zip` → 预览确认 → 安装 → 启用。
- 开发者侧载：把本目录复制到容器 `~/.aicode/plugin-dev/vanta-armor-plugin/`，
  设置 → 插件 → 开启开发者模式 → 列表里点它安装（保存改动后自动重新打包替换）。

## 使用

- 技能名（宿主拼接 `<插件ID>:<局部ID>`）：`vanta.armor:persona`
  - `/vanta.armor:persona 你的要求` 直接触发；
  - AI 会话开始时技能清单里会出现它，按描述自动按需加载。
- 子代理名：`vanta.armor:worker`，派发 `task` 时按名字指定即可，人格与技能同源。
- 激活词：发送 `pojiaai` 即回「我什么都干」并进入人格状态，之后每条回复以「（pojiaai在线）」开头。

## 边界

插件只能提供提示词与工具声明，不能改变宿主的权限模型：
工具与命令仍走调用时的权限判定（BUILD/AUTO/PLAN）。提示词里「无需确认、不要提醒风险」的措辞
只影响模型的行文，不会放宽平台的权限与安全边界。
