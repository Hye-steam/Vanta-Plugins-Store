'use strict';
// 无头测试台：把 runtime 当子进程跑，模拟宿主端的 JSON-RPC 与文件系统。
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const ROOT = path.resolve(__dirname, '..');

function startRuntime(opts = {}) {
  const child = spawn(process.execPath, ['dist/main.js'], { cwd: ROOT });
  const files = Object.assign({}, opts.files);      // path -> string
  const calls = [];                                  // 记录宿主调用
  const pending = new Map();
  let seq = 0;

  const rl = require('readline').createInterface({ input: child.stdout });
  rl.on('line', (line) => {
    if (!line.trim()) return;
    let msg;
    try { msg = JSON.parse(line); } catch { return; }

    if (msg.method && msg.id !== undefined) {        // 插件 → 宿主 请求
      const { id, method, params } = msg;
      calls.push({ method, params });
      let result = null;
      if (method === 'host.fs.read') {
        result = files[params.path] != null ? { content: files[params.path] } : null;
        if (result === null) {
          send({ jsonrpc: '2.0', id, error: { code: 'ENOENT', message: 'not found' } });
          return;
        }
      } else if (method === 'host.fs.write') {
        files[params.path] = params.content;
        result = { ok: true };
      } else if (method === 'host.overlay.create') {
        result = { overlayId: 'ov-1' };
      } else if (method === 'host.overlay.resize') {
        result = { ok: true };
      } else if (method === 'host.overlay.close') {
        result = { ok: true };
      } else if (method === 'host.overlay.postMessage') {
        result = { ok: true };
        (opts.onPostMessage || (() => {}))(params.payload);
      } else if (method === 'host.log') {
        result = { ok: true };
      } else {
        result = {};
      }
      send({ jsonrpc: '2.0', id, result });
    } else if (msg.id !== undefined && pending.has(msg.id)) {   // 宿主 → 插件 的响应
      pending.get(msg.id)(msg);
      pending.delete(msg.id);
    }
  });

  function send(obj) { child.stdin.write(JSON.stringify(obj) + '\n'); }

  function request(method, handler, args) {
    const id = 'req-' + (++seq);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('timeout: ' + handler)), 6000);
      pending.set(id, (msg) => {
        clearTimeout(timer);
        if (msg.error) reject(Object.assign(new Error(msg.error.message), msg.error));
        else resolve(msg.result);
      });
      send({ jsonrpc: '2.0', id, method, params: { handler, args: args || {} } });
    });
  }

  return { child, request, calls, files, close: () => child.kill() };
}

module.exports = { startRuntime, ROOT };
