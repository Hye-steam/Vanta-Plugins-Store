import { d as defineComponent, r as resolveComponent, h, a as ref, n as normalizeSettings, M as MOOD_DEFAULT, c as computed, o as onMounted, b as onBeforeUnmount, e as openBlock, f as createElementBlock, g as createElementVNode, i as createVNode, w as withCtx, u as unref, t as toDisplayString, j as withDirectives, v as vModelText, F as Fragment, k as createCommentVNode, l as createTextVNode, m as withKeys, p as renderList, q as normalizeClass, s as createBlock, D as DEFAULT_SETTINGS, x as createApp } from "./settings-tieGc_Pm.js";
const _hoisted_1 = { class: "aicode-page" };
const _hoisted_2 = { class: "aicode-page-header" };
const _hoisted_3 = { class: "slider-row" };
const _hoisted_4 = { class: "slider-head" };
const _hoisted_5 = { class: "value" };
const _hoisted_6 = { class: "setting-text" };
const _hoisted_7 = { class: "setting-subtitle" };
const _hoisted_8 = { class: "setting-text" };
const _hoisted_9 = { class: "setting-subtitle" };
const _hoisted_10 = { class: "actions" };
const _hoisted_11 = { class: "slider-row" };
const _hoisted_12 = { class: "slider-head" };
const _hoisted_13 = { class: "value" };
const _hoisted_14 = { class: "music-search" };
const _hoisted_15 = { class: "music-account-text" };
const _hoisted_16 = { class: "music-account-sub" };
const _hoisted_17 = { class: "music-account-action" };
const _hoisted_18 = {
  key: 0,
  class: "voice-hint"
};
const _hoisted_19 = {
  key: 1,
  class: "music-results"
};
const _hoisted_20 = ["src"];
const _hoisted_21 = {
  key: 1,
  class: "music-cover music-cover-empty"
};
const _hoisted_22 = { class: "music-main" };
const _hoisted_23 = { class: "music-title" };
const _hoisted_24 = { class: "music-meta" };
const _hoisted_25 = { class: "music-detail" };
const _hoisted_26 = ["disabled", "onClick"];
const _hoisted_27 = ["onClick"];
const _hoisted_28 = { class: "music-pager" };
const _hoisted_29 = { class: "music-page-text" };
const _hoisted_30 = { class: "music-account-text" };
const _hoisted_31 = { class: "music-account-sub" };
const _hoisted_32 = { class: "music-account-text" };
const _hoisted_33 = { class: "music-account-sub" };
const _hoisted_34 = { class: "music-actions-row" };
const _hoisted_35 = { class: "quick-actions" };
const _hoisted_36 = { class: "footer-actions" };
const _hoisted_37 = { class: "music-account-row" };
const _hoisted_38 = ["src"];
const _hoisted_39 = { class: "music-account-name" };
const _hoisted_40 = { class: "music-account-id" };
const _hoisted_41 = { class: "music-dialog-actions" };
const _hoisted_42 = { class: "music-tabs" };
const _hoisted_43 = { class: "music-qr-area" };
const _hoisted_44 = ["src"];
const _hoisted_45 = {
  key: 1,
  class: "music-qr-placeholder"
};
const _hoisted_46 = { class: "voice-hint" };
const _hoisted_47 = { class: "music-dialog-actions" };
const _hoisted_48 = {
  key: 2,
  class: "voice-hint"
};
const _hoisted_49 = {
  key: 0,
  class: "voice-hint"
};
const _hoisted_50 = {
  key: 0,
  class: "voice-hint"
};
const _hoisted_51 = {
  key: 1,
  class: "music-results"
};
const _hoisted_52 = ["onClick"];
const _hoisted_53 = ["src"];
const _hoisted_54 = {
  key: 1,
  class: "music-cover music-cover-empty"
};
const _hoisted_55 = { class: "music-account-text" };
const _hoisted_56 = { class: "music-account-title" };
const _hoisted_57 = { class: "music-account-sub" };
const _hoisted_58 = {
  key: 2,
  class: "voice-hint"
};
const _hoisted_59 = { class: "music-dialog-actions" };
const _hoisted_60 = {
  key: 0,
  class: "voice-hint"
};
const _hoisted_61 = {
  key: 1,
  class: "music-results"
};
const _hoisted_62 = ["src"];
const _hoisted_63 = {
  key: 1,
  class: "music-cover music-cover-empty"
};
const _hoisted_64 = { class: "music-main" };
const _hoisted_65 = { class: "music-title" };
const _hoisted_66 = { class: "music-meta" };
const _hoisted_67 = { class: "music-detail" };
const _hoisted_68 = ["disabled", "onClick"];
const _hoisted_69 = ["onClick"];
const _hoisted_70 = {
  key: 2,
  class: "music-dialog-actions"
};
const _hoisted_71 = { class: "music-tabs" };
const _hoisted_72 = ["onClick"];
const _hoisted_73 = { class: "music-dialog-actions" };
const _hoisted_74 = {
  key: 0,
  class: "voice-hint"
};
const _hoisted_75 = {
  key: 1,
  class: "music-results"
};
const _hoisted_76 = ["src"];
const _hoisted_77 = {
  key: 1,
  class: "music-cover music-cover-empty"
};
const _hoisted_78 = { class: "music-main" };
const _hoisted_79 = { class: "music-title" };
const _hoisted_80 = { class: "music-meta" };
const _hoisted_81 = ["disabled", "onClick"];
const _hoisted_82 = ["onClick"];
const _hoisted_83 = {
  key: 2,
  class: "voice-hint"
};
const _hoisted_84 = {
  key: 0,
  class: "voice-hint"
};
const _hoisted_85 = {
  key: 0,
  class: "voice-hint"
};
const _hoisted_86 = { class: "voice-hint" };
const _hoisted_87 = { class: "voice-hint" };
const _hoisted_88 = { class: "tts-actions" };
const _hoisted_89 = {
  key: 2,
  class: "voice-hint"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "config",
  setup(__props) {
    const SettingSwitch = defineComponent({
      name: "SettingSwitch",
      props: {
        modelValue: { type: Boolean, default: false },
        title: { type: String, default: "" },
        subtitle: { type: String, default: "" },
        disabled: { type: Boolean, default: false }
      },
      emits: ["update:modelValue"],
      setup(props, { emit }) {
        const Switch = resolveComponent("aicode-switch");
        return () => h("div", { class: "setting-line" }, [
          h("span", { class: "setting-text" }, [
            h("span", { class: "setting-title" }, props.title),
            props.subtitle ? h("span", { class: "setting-subtitle" }, props.subtitle) : null
          ]),
          h(Switch, {
            modelValue: props.modelValue,
            disabled: props.disabled,
            "onUpdate:modelValue": (value) => emit("update:modelValue", value)
          })
        ]);
      }
    });
    const ctx = ref(null);
    const settings = ref(normalizeSettings(DEFAULT_SETTINGS));
    const petState = ref({
      sleeping: false,
      runActive: false,
      toolsActive: 0,
      mood: MOOD_DEFAULT,
      lastAnimation: null,
      lastText: "",
      updatedAt: 0
    });
    const saving = ref(false);
    const busy = ref(false);
    const confirmOpen = ref(false);
    const modelPickerOpen = ref(false);
    const voiceOptions = ref([]);
    const voiceHint = ref("");
    const ttsOpen = ref(false);
    const ttsHint = ref("");
    const ttsHasKey = ref(false);
    const ttsKeyInput = ref("");
    const ttsDraft = ref({
      provider: "none",
      providerId: "",
      baseUrl: "",
      model: "",
      voice: "",
      speed: 1
    });
    const ttsProviderPickerOptions = computed(() => [
      { value: "", label: "未选择" },
      { value: "__custom__", label: "自定义（任意兼容服务）" },
      ...ttsPresets.value.map((preset) => ({
        value: preset.providerId,
        label: preset.providerName + (preset.hasKey ? "" : "（未配置密钥）")
      }))
    ]);
    const ttsAddressHint = computed(
      () => ttsDraft.value.providerId ? "宿主不会把该供应商的地址与密钥交给插件，所以这两项需在这里各填一次；密钥由宿主加密存储。" : "自定义服务需填完整地址（例如 http://127.0.0.1:8788/v1）与密钥；留空则用该协议的官方地址。"
    );
    const ttsModelPick = ref("");
    const ttsPresets = ref([]);
    const isCustomProvider = computed(() => ttsDraft.value.providerId === "__custom__");
    const ttsProviderModels = computed(
      () => {
        var _a, _b;
        return isCustomProvider.value ? [] : (_b = (_a = voiceOptions.value.find((p) => p.id === ttsDraft.value.providerId)) == null ? void 0 : _a.models) != null ? _b : [];
      }
    );
    const ttsModelOptions = computed(() => [
      ...ttsProviderModels.value.map((model) => ({ value: model.id, label: model.displayName || model.id })),
      { value: "__manual__", label: "以上都不是，手动填写" }
    ]);
    const ttsModelHint = computed(() => {
      if (isCustomProvider.value) return "自定义服务没有可列举的模型，请直接填写语音模型名。";
      if (!ttsDraft.value.providerId) return "先选一个供应商，就能列出它已配置的模型。";
      if (ttsProviderModels.value.length === 0) {
        return "这个供应商没有可枚举的模型，请把语音模型名填到下面的输入框。";
      }
      return "这些是你在 AiCode 里为该供应商配置的模型；若语音模型不在列表里，选「手动填写」后输入名称。";
    });
    const ttsModelPlaceholder = computed(
      () => ttsDraft.value.provider === "gemini" ? "gemini-2.5-flash-preview-tts" : "gpt-4o-mini-tts"
    );
    const ttsVoicePlaceholder = computed(
      () => ttsDraft.value.provider === "gemini" ? "Kore" : "alloy / nova / shimmer …"
    );
    const ttsBaseUrlPlaceholder = computed(
      () => ttsDraft.value.provider === "gemini" ? "https://generativelanguage.googleapis.com/v1beta" : "https://api.openai.com/v1"
    );
    const ttsSubtitle = computed(() => {
      const tts = settings.value.voice.tts;
      if (tts.provider === "none") return "未启用";
      const name = tts.provider === "gemini" ? "Gemini" : "OpenAI 兼容";
      const voice = tts.voice ? ` · ${tts.voice}` : "";
      const key = ttsHasKey || tts.hasKey ? "" : " · 缺少密钥";
      return name + voice + key;
    });
    const voiceDraft = ref({ providerId: "", model: "" });
    const status = ref("");
    let offEvents = null;
    const sleeping = computed(() => petState.value.sleeping);
    const providerOptions = computed(() => [
      { value: "", label: "未选择" },
      ...voiceOptions.value.map((provider) => ({ value: provider.id, label: provider.name }))
    ]);
    const modelOptions = computed(() => {
      var _a, _b;
      return [
        { value: "", label: "使用该供应商的默认模型" },
        ...((_b = (_a = voiceOptions.value.find((provider) => provider.id === voiceDraft.value.providerId)) == null ? void 0 : _a.models) != null ? _b : []).map(
          (model) => ({ value: model.id, label: model.displayName || model.id })
        )
      ];
    });
    const providerSubtitle = computed(() => {
      var _a;
      const { providerId, model } = settings.value.voice;
      if (!providerId) return "自动挑选已配置的默认供应商";
      const provider = voiceOptions.value.find((item) => item.id === providerId);
      const name = (_a = provider == null ? void 0 : provider.name) != null ? _a : providerId;
      return model ? `${name} · ${model}` : `${name} · 默认模型`;
    });
    const statusSubtitle = computed(() => {
      const parts = [];
      if (petState.value.sleeping) parts.push("睡眠中");
      if (petState.value.runActive) parts.push("AI 运行中");
      if (petState.value.toolsActive > 0) parts.push(`${petState.value.toolsActive} 个工具执行中`);
      if (parts.length === 0) parts.push("空闲");
      if (petState.value.lastText) parts.push(petState.value.lastText);
      if (status.value) parts.push(status.value);
      return parts.join(" · ");
    });
    function applyResult(result) {
      if (result == null ? void 0 : result.settings) settings.value = normalizeSettings(result.settings);
    }
    function launchHint(code) {
      if (code === "OVERLAY_NOT_AUTHORIZED") return "尚未在插件详情中开启悬浮窗授权";
      if (code === "OVERLAY_SYSTEM_PERMISSION_MISSING") return "系统尚未允许 AiCode 显示在其他应用上层";
      return "桌宠浮层暂不可用：" + code;
    }
    async function loadVoiceOptions() {
      var _a;
      try {
        const result = await aicode.invoke("ui.voice.options");
        voiceOptions.value = (_a = result == null ? void 0 : result.providers) != null ? _a : [];
        voiceHint.value = (result == null ? void 0 : result.error) ? "读取供应商失败：" + result.error : "";
      } catch (error) {
        voiceHint.value = "读取供应商失败：" + error.message;
      }
    }
    async function load() {
      try {
        const context = await aicode.context();
        if ("overlayId" in context) return;
        ctx.value = context;
        const result = await aicode.invoke("ui.pet.state");
        applyResult(result);
        if (result == null ? void 0 : result.state) petState.value = result.state;
        if (result == null ? void 0 : result.launchError) status.value = launchHint(result.launchError);
        await loadVoiceOptions();
      } catch (error) {
        status.value = "读取设置失败：" + error.message;
      }
    }
    async function save() {
      saving.value = true;
      try {
        const result = await aicode.invoke("ui.settings.save", { settings: settings.value });
        applyResult(result);
        if ((result == null ? void 0 : result.overlayOpen) === false && settings.value.pet.enabled) {
          status.value = launchHint(result.launchError || "OVERLAY_FAILED");
        } else {
          status.value = settings.value.pet.enabled ? "已保存" : "已保存，桌宠浮层已移除";
        }
        await aicode.toast("桌宠设置已保存").catch(() => {
        });
      } catch (error) {
        status.value = "保存失败：" + error.message;
      } finally {
        saving.value = false;
      }
    }
    async function toggleVoice(enabled) {
      settings.value = {
        ...settings.value,
        voice: { ...settings.value.voice, mode: enabled ? "auto" : "canned" }
      };
      if (enabled) await loadVoiceOptions();
      await save();
    }
    function openModelPicker() {
      voiceDraft.value = { providerId: settings.value.voice.providerId, model: settings.value.voice.model };
      modelPickerOpen.value = true;
    }
    function onProviderChange() {
      voiceDraft.value.model = "";
    }
    async function applyModelChoice() {
      settings.value = {
        ...settings.value,
        voice: { ...settings.value.voice, providerId: voiceDraft.value.providerId, model: voiceDraft.value.model }
      };
      const preset = ttsPresets.value.find((item) => item.providerId === voiceDraft.value.providerId);
      if (preset && settings.value.voice.tts.provider !== "none" && settings.value.voice.tts.provider !== preset.tts.provider) {
        settings.value = {
          ...settings.value,
          voice: {
            ...settings.value.voice,
            tts: { ...settings.value.voice.tts, provider: preset.tts.provider, model: "" }
          }
        };
      }
      await save();
    }
    async function loadTtsState() {
      var _a;
      try {
        const [result, presets] = await Promise.all([
          aicode.invoke("ui.tts.state"),
          aicode.invoke("ui.tts.presets")
        ]);
        if (result == null ? void 0 : result.tts) settings.value = { ...settings.value, voice: { ...settings.value.voice, tts: result.tts } };
        ttsHasKey.value = (result == null ? void 0 : result.hasKey) === true;
        ttsPresets.value = (_a = presets == null ? void 0 : presets.presets) != null ? _a : [];
        if (presets == null ? void 0 : presets.error) ttsHint.value = "读取供应商失败：" + presets.error;
      } catch (error) {
        ttsHint.value = "读取 TTS 状态失败：" + error.message;
      }
    }
    function onTtsModelPick() {
      if (ttsModelPick.value === "__manual__") return;
      if (ttsModelPick.value) ttsDraft.value.model = ttsModelPick.value;
    }
    async function toggleSpeakAloud(enabled) {
      settings.value = { ...settings.value, voice: { ...settings.value.voice, speakAloud: enabled } };
      await save();
      if (enabled) {
        await loadTtsState();
        if (settings.value.voice.tts.provider === "none") openTtsSheet();
      }
    }
    function openTtsSheet() {
      const tts = settings.value.voice.tts;
      ttsDraft.value = {
        provider: tts.provider,
        providerId: tts.providerId,
        baseUrl: tts.baseUrl,
        model: tts.model,
        voice: tts.voice,
        speed: tts.speed
      };
      ttsKeyInput.value = "";
      ttsHint.value = "";
      if (!tts.providerId) ttsDraft.value.providerId = "__custom__";
      if (tts.provider === "none") {
        const preset = ttsPresets.value.find((item) => item.providerId === tts.providerId);
        ttsDraft.value.provider = preset ? preset.tts.provider : "openai";
      }
      syncTtsModelPick();
      ttsOpen.value = true;
      void loadTtsState().then(syncTtsModelPick);
    }
    function syncTtsModelPick() {
      var _a, _b;
      const models = (_b = (_a = voiceOptions.value.find((p) => p.id === ttsDraft.value.providerId)) == null ? void 0 : _a.models) != null ? _b : [];
      ttsModelPick.value = models.some((m) => m.id === ttsDraft.value.model) ? ttsDraft.value.model : "__manual__";
    }
    function onTtsProviderPick() {
      var _a, _b;
      if (ttsDraft.value.providerId === "__custom__") {
        const looksGemini = /generativelanguage\.googleapis\.com/i.test(ttsDraft.value.baseUrl);
        ttsDraft.value.provider = looksGemini ? "gemini" : "openai";
        ttsModelPick.value = "__manual__";
        return;
      }
      const preset = ttsPresets.value.find((item) => item.providerId === ttsDraft.value.providerId);
      if (!preset) {
        ttsModelPick.value = "__manual__";
        return;
      }
      ttsDraft.value.provider = preset.tts.provider;
      ttsDraft.value.baseUrl = "";
      const keep = ttsDraft.value.model;
      const exists = ((_b = (_a = voiceOptions.value.find((p) => p.id === ttsDraft.value.providerId)) == null ? void 0 : _a.models) != null ? _b : []).some(
        (model) => model.id === keep
      );
      if (!exists) ttsDraft.value.model = "";
      ttsModelPick.value = exists ? keep : "__manual__";
    }
    async function disableTts() {
      settings.value = {
        ...settings.value,
        voice: {
          ...settings.value.voice,
          speakAloud: false,
          tts: { ...settings.value.voice.tts, provider: "none" }
        }
      };
      await save();
      ttsOpen.value = false;
    }
    async function saveTts() {
      busy.value = true;
      try {
        if (ttsKeyInput.value.trim()) {
          const saved = await aicode.invoke("ui.tts.saveKey", { apiKey: ttsKeyInput.value.trim() });
          ttsHasKey.value = (saved == null ? void 0 : saved.hasKey) === true;
          ttsKeyInput.value = "";
        }
        const draft = ttsDraft.value;
        settings.value = {
          ...settings.value,
          voice: {
            ...settings.value.voice,
            speakAloud: settings.value.voice.speakAloud,
            tts: {
              provider: draft.provider,
              providerId: draft.providerId === "__custom__" ? "" : draft.providerId,
              baseUrl: draft.baseUrl.trim(),
              model: draft.model.trim(),
              voice: draft.voice.trim(),
              hasKey: ttsHasKey.value,
              speed: draft.speed
            }
          }
        };
        await save();
        ttsHint.value = draft.provider === "none" ? "已关闭 TTS" : "已保存，可试听确认";
      } catch (error) {
        ttsHint.value = "保存失败：" + error.message;
      } finally {
        busy.value = false;
      }
    }
    async function previewTts() {
      busy.value = true;
      ttsHint.value = "正在合成…";
      try {
        const probe = await aicode.invoke("ui.tts.probe", {
          baseUrl: ttsDraft.value.baseUrl,
          provider: ttsDraft.value.provider
        });
        if (probe && probe.ok === false) {
          ttsHint.value = probe.reason || "该地址没有语音合成接口";
          return;
        }
        await saveTts();
        const result = await aicode.invoke("ui.tts.preview");
        ttsHint.value = (result == null ? void 0 : result.ok) ? "已发送到桌宠播放" : (result == null ? void 0 : result.reason) || "试听失败";
      } catch (error) {
        ttsHint.value = "试听失败：" + error.message;
      } finally {
        busy.value = false;
      }
    }
    async function ensureOpen() {
      const opened = await aicode.invoke("ui.pet.open");
      if (opened == null ? void 0 : opened.ok) return true;
      status.value = launchHint((opened == null ? void 0 : opened.code) || "OVERLAY_FAILED");
      return false;
    }
    async function reset() {
      busy.value = true;
      try {
        const result = await aicode.invoke("ui.settings.reset");
        applyResult(result);
        status.value = await ensureOpen() ? "已恢复默认设置" : "已恢复默认设置，但桌宠浮层暂不可用";
        await aicode.toast("已恢复默认设置").catch(() => {
        });
      } catch (error) {
        status.value = "重置失败：" + error.message;
      } finally {
        busy.value = false;
        confirmOpen.value = false;
      }
    }
    async function sayHello() {
      busy.value = true;
      try {
        await save();
        if (!await ensureOpen()) return;
        const result = await aicode.invoke("ui.pet.say");
        status.value = (result == null ? void 0 : result.source) === "model" ? "模型已按人设说话" : "已用内置语料说话";
      } catch (error) {
        status.value = "操作失败：" + error.message;
      } finally {
        busy.value = false;
      }
    }
    async function interact(kind) {
      var _a;
      busy.value = true;
      try {
        if (!await ensureOpen()) return;
        const result = await aicode.invoke("ui.pet.interact", { kind });
        petState.value = { ...petState.value, mood: (_a = result == null ? void 0 : result.mood) != null ? _a : petState.value.mood };
        status.value = (kind === "headpat" ? "已摸摸头" : "已喂点心") + ((result == null ? void 0 : result.source) === "model" ? "（模型回应）" : "");
      } catch (error) {
        status.value = "操作失败：" + error.message;
      } finally {
        busy.value = false;
      }
    }
    async function playAction() {
      busy.value = true;
      try {
        if (!await ensureOpen()) return;
        await aicode.invoke("ui.pet.play", { animation: settings.value.animations.action });
        status.value = "已播放动作";
      } catch (error) {
        status.value = "操作失败：" + error.message;
      } finally {
        busy.value = false;
      }
    }
    async function toggleSleep() {
      busy.value = true;
      try {
        if (!await ensureOpen()) return;
        petState.value = { ...petState.value, sleeping: !petState.value.sleeping };
        await aicode.invoke("tools.sleep", { action: "toggle" });
        status.value = petState.value.sleeping ? "已哄它睡觉" : "已叫醒";
      } catch (error) {
        status.value = "操作失败：" + error.message;
      } finally {
        busy.value = false;
      }
    }
    async function hidePet() {
      busy.value = true;
      try {
        const result = await aicode.invoke("ui.pet.hide");
        applyResult(result);
        status.value = "桌宠浮层已隐藏";
      } catch (error) {
        status.value = "操作失败：" + error.message;
      } finally {
        busy.value = false;
      }
    }
    async function showPet() {
      busy.value = true;
      try {
        const result = await aicode.invoke("ui.pet.show");
        applyResult(result);
        status.value = await ensureOpen() ? "已重新显示桌宠" : "设置已保存，但桌宠浮层暂不可用";
      } catch (error) {
        status.value = "操作失败：" + error.message;
      } finally {
        busy.value = false;
      }
    }
    const musicKeywords = ref("");
    const musicSongs = ref([]);
    const musicPage = ref(1);
    const musicLoading = ref(false);
    const musicHint = ref("");
    const musicApiBaseUrl = ref("https://music.api.hoilai.cn");
    const musicAccount = ref(null);
    const musicAccountOpen = ref(false);
    const musicTab = ref("qr");
    const musicQrImage = ref("");
    const musicQrKey = ref("");
    const musicQrHint = ref("");
    const musicMobile = ref("");
    const musicCode = ref("");
    const musicLoginHint = ref("");
    const musicBusy = ref(false);
    let musicQrTimer = null;
    function stopMusicQrPolling() {
      if (musicQrTimer) {
        clearInterval(musicQrTimer);
        musicQrTimer = null;
      }
    }
    function formatMusicDuration(seconds) {
      if (!seconds || seconds < 0) return "--:--";
      const total = Math.round(seconds);
      const mm = Math.floor(total / 60);
      const ss = total % 60;
      return mm + ":" + String(ss).padStart(2, "0");
    }
    async function refreshMusicAccount() {
      try {
        const result = await aicode.invoke("ui.music.account");
        musicAccount.value = (result == null ? void 0 : result.signedIn) && result.account ? result.account : null;
      } catch (e) {
        musicAccount.value = null;
      }
    }
    async function loadMusicSettings() {
      const current = settings.value.music;
      if (current == null ? void 0 : current.apiBaseUrl) musicApiBaseUrl.value = current.apiBaseUrl;
    }
    async function saveMusicSettings() {
      try {
        const result = await aicode.invoke("ui.settings.save", {
          settings: { ...settings.value, music: { ...settings.value.music, apiBaseUrl: musicApiBaseUrl.value } }
        });
        if (result == null ? void 0 : result.settings) settings.value = normalizeSettings(result.settings);
        musicApiBaseUrl.value = settings.value.music.apiBaseUrl;
      } catch (error) {
        musicHint.value = "保存接口地址失败：" + error.message;
      }
    }
    async function searchMusic(target) {
      var _a, _b;
      const word = musicKeywords.value.trim();
      if (!word) return;
      musicLoading.value = true;
      musicHint.value = "";
      try {
        const result = await aicode.invoke("ui.music.search", {
          keywords: word,
          page: target
        });
        if ((result == null ? void 0 : result.ok) !== true) {
          musicHint.value = (result == null ? void 0 : result.message) || "搜索失败";
          musicSongs.value = [];
          return;
        }
        musicSongs.value = (_a = result.songs) != null ? _a : [];
        musicPage.value = (_b = result.page) != null ? _b : target;
        if (musicSongs.value.length === 0) musicHint.value = "没有找到结果，换个关键词试试。";
      } catch (error) {
        musicHint.value = "搜索失败：" + error.message;
      } finally {
        musicLoading.value = false;
      }
    }
    function openMusicAccount() {
      musicAccountOpen.value = true;
      musicLoginHint.value = "";
      if (musicAccount.value) return;
      if (musicTab.value === "qr") void openMusicQr();
    }
    async function openMusicQr() {
      var _a;
      musicTab.value = "qr";
      stopMusicQrPolling();
      musicQrImage.value = "";
      musicQrHint.value = "正在获取二维码…";
      try {
        const result = await aicode.invoke("ui.music.qr");
        if ((result == null ? void 0 : result.ok) !== true || !result.key) {
          musicQrHint.value = (result == null ? void 0 : result.message) || "二维码获取失败";
          return;
        }
        musicQrKey.value = result.key;
        musicQrImage.value = (_a = result.image) != null ? _a : "";
        musicQrHint.value = "用酷狗音乐 App 扫码登录";
        musicQrTimer = setInterval(() => {
          void pollMusicQr();
        }, 3e3);
      } catch (error) {
        musicQrHint.value = "二维码获取失败：" + error.message;
      }
    }
    async function pollMusicQr() {
      var _a, _b;
      if (!musicQrKey.value || musicAccount.value) {
        stopMusicQrPolling();
        return;
      }
      try {
        const result = await aicode.invoke("ui.music.qrCheck", { key: musicQrKey.value });
        if ((result == null ? void 0 : result.ok) !== true) {
          musicQrHint.value = (result == null ? void 0 : result.message) || "二维码状态查询失败";
          stopMusicQrPolling();
          return;
        }
        const status2 = (_a = result.status) != null ? _a : 0;
        if (status2 === 2) musicQrHint.value = "已扫码，请在手机上确认";
        else if (status2 === 4) {
          musicQrHint.value = "登录成功";
          stopMusicQrPolling();
          musicAccount.value = (_b = result.account) != null ? _b : null;
          await refreshMusicAccount();
        } else if (status2 === 0) {
          musicQrHint.value = "二维码已过期，请重新打开";
          stopMusicQrPolling();
        }
      } catch (error) {
        musicQrHint.value = "状态查询失败：" + error.message;
        stopMusicQrPolling();
      }
    }
    async function sendMusicCode() {
      musicBusy.value = true;
      musicLoginHint.value = "";
      try {
        const result = await aicode.invoke("ui.music.sendCode", {
          mobile: musicMobile.value.trim()
        });
        musicLoginHint.value = (result == null ? void 0 : result.ok) === true ? "验证码已发送" : (result == null ? void 0 : result.message) || "发送失败";
      } catch (error) {
        musicLoginHint.value = "发送失败：" + error.message;
      } finally {
        musicBusy.value = false;
      }
    }
    async function loginMusicByPhone() {
      musicBusy.value = true;
      musicLoginHint.value = "";
      try {
        const result = await aicode.invoke(
          "ui.music.loginPhone",
          { mobile: musicMobile.value.trim(), code: musicCode.value.trim() }
        );
        if ((result == null ? void 0 : result.ok) === true) {
          musicLoginHint.value = "登录成功";
          await refreshMusicAccount();
          musicAccountOpen.value = false;
        } else {
          musicLoginHint.value = (result == null ? void 0 : result.message) || "登录失败";
        }
      } catch (error) {
        musicLoginHint.value = "登录失败：" + error.message;
      } finally {
        musicBusy.value = false;
      }
    }
    async function logoutMusic() {
      musicBusy.value = true;
      try {
        await aicode.invoke("ui.music.logout");
        musicAccount.value = null;
        musicLoginHint.value = "已退出登录";
        musicQrImage.value = "";
        musicQrHint.value = "";
      } catch (error) {
        musicLoginHint.value = "退出失败：" + error.message;
      } finally {
        musicBusy.value = false;
      }
    }
    const accountPlaylists = ref([]);
    const accountListsOpen = ref(false);
    const accountListHint = ref("");
    const accountSongsOpen = ref(false);
    const accountSongs = ref([]);
    const accountSongHint = ref("");
    const currentAccountList = ref(null);
    const accountPlaylistSub = computed(() => {
      if (!musicAccount.value) return "未登录";
      if (accountPlaylists.value.length === 0) return "点击读取账号歌单";
      return accountPlaylists.value.length + " 个歌单";
    });
    async function loadAccountPlaylists() {
      var _a;
      musicBusy.value = true;
      accountListHint.value = "";
      try {
        const result = await aicode.invoke("ui.music.accountPlaylists");
        if ((result == null ? void 0 : result.ok) !== true) {
          accountListHint.value = (result == null ? void 0 : result.message) || "读取账号歌单失败";
          accountPlaylists.value = [];
          return;
        }
        accountPlaylists.value = (_a = result.playlists) != null ? _a : [];
        if (accountPlaylists.value.length === 0) {
          accountListHint.value = "账号里没有歌单，或登录态已失效，可重新登录后再试。";
        }
      } catch (error) {
        accountListHint.value = "读取账号歌单失败：" + error.message;
      } finally {
        musicBusy.value = false;
      }
    }
    async function openAccountPlaylists() {
      accountListsOpen.value = true;
      accountListHint.value = "";
      if (!musicAccount.value) {
        accountListHint.value = "未登录：账号歌单需要先登录。";
        return;
      }
      await loadAccountPlaylists();
    }
    async function openAccountPlaylist(list) {
      var _a;
      currentAccountList.value = list;
      accountSongs.value = [];
      accountSongHint.value = "";
      accountSongsOpen.value = true;
      musicBusy.value = true;
      try {
        const result = await aicode.invoke(
          "ui.music.playlistSongs",
          { id: list.id }
        );
        if ((result == null ? void 0 : result.ok) !== true) {
          accountSongHint.value = (result == null ? void 0 : result.message) || "读取歌单歌曲失败";
          return;
        }
        accountSongs.value = (_a = result.songs) != null ? _a : [];
        if (accountSongs.value.length === 0) accountSongHint.value = "这个歌单里没有歌曲。";
      } catch (error) {
        accountSongHint.value = "读取歌单歌曲失败：" + error.message;
      } finally {
        musicBusy.value = false;
      }
    }
    async function singCurrentPlaylist() {
      var _a, _b;
      if (!currentAccountList.value) return;
      musicBusy.value = true;
      try {
        const result = await aicode.invoke(
          "ui.pet.singPlaylist",
          { playlistId: currentAccountList.value.id }
        );
        accountSongHint.value = (result == null ? void 0 : result.ok) === true ? "桌宠正在唱：" + ((_b = (_a = result.song) == null ? void 0 : _a.title) != null ? _b : "") : (result == null ? void 0 : result.message) || "唱歌失败";
      } catch (error) {
        accountSongHint.value = "唱歌失败：" + error.message;
      } finally {
        musicBusy.value = false;
      }
    }
    const favoriteLists = ref([]);
    const favoriteHashes = ref([]);
    const favoriteSongs = ref([]);
    const currentListId = ref("");
    const favoritesOpen = ref(false);
    const favoriteHint = ref("");
    const favoriteTotalCount = computed(() => favoriteLists.value.reduce((sum, list) => sum + list.count, 0));
    const favoriteSummaryText = computed(() => {
      if (favoriteLists.value.length === 0) return "还没有歌单";
      return favoriteLists.value.map((list) => list.name + " " + list.count).join(" · ");
    });
    async function refreshFavorites() {
      var _a, _b;
      try {
        const [lists, hashes] = await Promise.all([
          aicode.invoke("ui.music.favorites"),
          aicode.invoke("ui.music.favoriteHashes")
        ]);
        favoriteLists.value = (_a = lists == null ? void 0 : lists.lists) != null ? _a : [];
        favoriteHashes.value = (_b = hashes == null ? void 0 : hashes.hashes) != null ? _b : [];
        if (!currentListId.value && favoriteLists.value.length > 0) {
          currentListId.value = favoriteLists.value[0].id;
        }
      } catch (error) {
        favoriteHint.value = "读取收藏失败：" + error.message;
      }
    }
    async function loadListSongs(id) {
      var _a, _b;
      if (!id) {
        favoriteSongs.value = [];
        return;
      }
      try {
        const result = await aicode.invoke(
          "ui.music.favoriteList",
          { id }
        );
        if ((result == null ? void 0 : result.ok) === true) favoriteSongs.value = (_b = (_a = result.list) == null ? void 0 : _a.songs) != null ? _b : [];
        else favoriteHint.value = (result == null ? void 0 : result.message) || "读取歌单失败";
      } catch (error) {
        favoriteHint.value = "读取歌单失败：" + error.message;
      }
    }
    async function toggleFavorite(song) {
      const isFav = favoriteHashes.value.includes(song.hash);
      try {
        const result = await aicode.invoke("ui.music.toggleFavorite", {
          song,
          listId: currentListId.value,
          remove: isFav
        });
        if ((result == null ? void 0 : result.ok) !== true) {
          musicHint.value = (result == null ? void 0 : result.message) || "收藏失败";
          return;
        }
        await refreshFavorites();
        await loadListSongs(currentListId.value);
        musicHint.value = isFav ? "已取消收藏" : "已加入收藏";
      } catch (error) {
        musicHint.value = "收藏失败：" + error.message;
      }
    }
    async function openFavorites() {
      favoritesOpen.value = true;
      favoriteHint.value = "";
      await refreshFavorites();
      if (!currentListId.value && favoriteLists.value.length === 0) {
        await createFavoriteList();
        return;
      }
      await loadListSongs(currentListId.value);
    }
    async function selectList(id) {
      currentListId.value = id;
      await loadListSongs(id);
    }
    async function createFavoriteList() {
      try {
        const result = await aicode.invoke("ui.music.createList", {
          name: "收藏 " + (favoriteLists.value.length + 1)
        });
        if ((result == null ? void 0 : result.ok) === true && result.list) {
          currentListId.value = result.list.id;
          await refreshFavorites();
          await loadListSongs(currentListId.value);
        }
      } catch (error) {
        favoriteHint.value = "新建失败：" + error.message;
      }
    }
    async function removeCurrentList() {
      if (!currentListId.value) return;
      try {
        await aicode.invoke("ui.music.deleteList", { id: currentListId.value });
        currentListId.value = "";
        favoriteSongs.value = [];
        await refreshFavorites();
        await loadListSongs(currentListId.value);
      } catch (error) {
        favoriteHint.value = "删除失败：" + error.message;
      }
    }
    async function removeFavoriteSong(song) {
      try {
        await aicode.invoke("ui.music.removeSong", { listId: currentListId.value, hash: song.hash });
        await refreshFavorites();
        await loadListSongs(currentListId.value);
      } catch (error) {
        favoriteHint.value = "移除失败：" + error.message;
      }
    }
    async function singFromPet() {
      var _a, _b;
      musicBusy.value = true;
      try {
        const result = await aicode.invoke(
          "ui.pet.sing",
          { listId: currentListId.value }
        );
        musicHint.value = (result == null ? void 0 : result.ok) === true ? "桌宠正在唱：" + ((_b = (_a = result.song) == null ? void 0 : _a.title) != null ? _b : "（若无声，先点一下桌宠再试）") : (result == null ? void 0 : result.message) || "唱歌失败";
      } catch (error) {
        musicHint.value = "唱歌失败：" + error.message;
      } finally {
        musicBusy.value = false;
      }
    }
    async function playSongItem(song) {
      var _a;
      musicBusy.value = true;
      try {
        const result = await aicode.invoke("ui.music.playUrl", { song });
        if ((result == null ? void 0 : result.ok) !== true) {
          musicHint.value = (result == null ? void 0 : result.reason) || (result == null ? void 0 : result.message) || "无法播放";
          return;
        }
        const token = (_a = result.audioToken) != null ? _a : "";
        musicHint.value = token ? "正在播放：" + song.title + "（若无声，先点一下桌宠）" : "音频准备失败，请重试";
      } catch (error) {
        musicHint.value = "播放失败：" + error.message;
      } finally {
        musicBusy.value = false;
      }
    }
    onMounted(async () => {
      offEvents = aicode.events.on((event) => {
        if (event.name === "pet.state" && event.payload && typeof event.payload === "object") {
          petState.value = event.payload;
        } else if (event.name === "pet.error") {
          const payload = event.payload;
          if (payload == null ? void 0 : payload.code) status.value = launchHint(payload.code);
        }
      });
      await load();
      await loadTtsState();
      await loadMusicSettings();
      await refreshMusicAccount();
      await refreshFavorites();
      if (musicAccount.value) await loadAccountPlaylists();
    });
    onBeforeUnmount(() => {
      if (offEvents) offEvents();
      stopMusicQrPolling();
    });
    return (_ctx, _cache) => {
      const _component_aicode_badge = resolveComponent("aicode-badge");
      const _component_aicode_divider = resolveComponent("aicode-divider");
      const _component_aicode_group = resolveComponent("aicode-group");
      const _component_aicode_input = resolveComponent("aicode-input");
      const _component_aicode_field = resolveComponent("aicode-field");
      const _component_aicode_textarea = resolveComponent("aicode-textarea");
      const _component_aicode_button = resolveComponent("aicode-button");
      const _component_aicode_info_row = resolveComponent("aicode-info-row");
      const _component_aicode_dialog = resolveComponent("aicode-dialog");
      const _component_aicode_select = resolveComponent("aicode-select");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createElementVNode("header", _hoisted_2, [
          _cache[45] || (_cache[45] = createElementVNode(
            "h1",
            { class: "aicode-page-title" },
            "桌宠设置",
            -1
            /* CACHED */
          )),
          createVNode(_component_aicode_badge, {
            text: "AiCode 浮层",
            kind: "plugin"
          })
        ]),
        createVNode(_component_aicode_group, { title: "显示" }, {
          default: withCtx(() => [
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.pet.enabled,
              "onUpdate:modelValue": [
                _cache[0] || (_cache[0] = ($event) => settings.value.pet.enabled = $event),
                save
              ],
              title: "启用桌宠",
              subtitle: "关闭后会移除系统悬浮窗，配置仍保留"
            }, null, 8, ["modelValue"]),
            createVNode(_component_aicode_divider),
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.pet.autoStart,
              "onUpdate:modelValue": [
                _cache[1] || (_cache[1] = ($event) => settings.value.pet.autoStart = $event),
                save
              ],
              title: "随 App 启动",
              subtitle: "打开 AiCode 时自动创建桌宠浮层"
            }, null, 8, ["modelValue"]),
            createVNode(_component_aicode_divider),
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.pet.alwaysOnTop,
              "onUpdate:modelValue": [
                _cache[2] || (_cache[2] = ($event) => settings.value.pet.alwaysOnTop = $event),
                save
              ],
              title: "始终置顶",
              subtitle: "关闭后桌宠只在 AiCode 位于前台时显示"
            }, null, 8, ["modelValue"]),
            createVNode(_component_aicode_divider),
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.pet.clickSound,
              "onUpdate:modelValue": [
                _cache[3] || (_cache[3] = ($event) => settings.value.pet.clickSound = $event),
                save
              ],
              title: "点击音效",
              subtitle: "点一下桌宠时播放合成的提示音"
            }, null, 8, ["modelValue"]),
            createVNode(_component_aicode_divider),
            createElementVNode("div", _hoisted_3, [
              createElementVNode("div", _hoisted_4, [
                _cache[46] || (_cache[46] = createElementVNode(
                  "span",
                  null,
                  "桌宠宽度",
                  -1
                  /* CACHED */
                )),
                createElementVNode(
                  "span",
                  _hoisted_5,
                  toDisplayString(settings.value.pet.size) + " dp",
                  1
                  /* TEXT */
                )
              ]),
              withDirectives(createElementVNode(
                "input",
                {
                  "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => settings.value.pet.size = $event),
                  type: "range",
                  min: "140",
                  max: "320",
                  step: "10",
                  onChange: save
                },
                null,
                544
                /* NEED_HYDRATION, NEED_PATCH */
              ), [
                [
                  vModelText,
                  settings.value.pet.size,
                  void 0,
                  { number: true }
                ]
              ])
            ])
          ]),
          _: 1
          /* STABLE */
        }),
        createVNode(_component_aicode_group, { title: "身份与说话" }, {
          default: withCtx(() => [
            createVNode(_component_aicode_field, { label: "桌宠名字" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_input, {
                  modelValue: settings.value.petName,
                  "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => settings.value.petName = $event),
                  placeholder: "蓝毛小女仆",
                  onBlur: save
                }, null, 8, ["modelValue"])
              ]),
              _: 1
              /* STABLE */
            }),
            createVNode(_component_aicode_field, { label: "人设" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_textarea, {
                  modelValue: settings.value.persona,
                  "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => settings.value.persona = $event),
                  placeholder: "决定桌宠用什么口吻说话",
                  onBlur: save
                }, null, 8, ["modelValue"])
              ]),
              _: 1
              /* STABLE */
            }),
            createVNode(_component_aicode_divider),
            createVNode(unref(SettingSwitch), {
              "model-value": settings.value.voice.mode === "auto",
              title: "用模型生成台词",
              subtitle: "按人设生成碎碎念与状态反馈；关闭后只用内置语料",
              "onUpdate:modelValue": toggleVoice
            }, null, 8, ["model-value"]),
            settings.value.voice.mode === "auto" ? (openBlock(), createElementBlock(
              Fragment,
              { key: 0 },
              [
                createVNode(_component_aicode_divider),
                createElementVNode("button", {
                  class: "setting-line",
                  type: "button",
                  onClick: openModelPicker
                }, [
                  createElementVNode("span", _hoisted_6, [
                    _cache[47] || (_cache[47] = createElementVNode(
                      "span",
                      { class: "setting-title" },
                      "供应商",
                      -1
                      /* CACHED */
                    )),
                    createElementVNode(
                      "span",
                      _hoisted_7,
                      toDisplayString(providerSubtitle.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _cache[48] || (_cache[48] = createElementVNode(
                    "span",
                    { class: "setting-action" },
                    "选择",
                    -1
                    /* CACHED */
                  ))
                ])
              ],
              64
              /* STABLE_FRAGMENT */
            )) : createCommentVNode("v-if", true),
            createVNode(_component_aicode_divider),
            createVNode(unref(SettingSwitch), {
              "model-value": settings.value.voice.speakAloud,
              title: "朗读台词",
              subtitle: "气泡出现时用云端语音念出来，需先配置 TTS",
              "onUpdate:modelValue": toggleSpeakAloud
            }, null, 8, ["model-value"]),
            settings.value.voice.speakAloud ? (openBlock(), createElementBlock(
              Fragment,
              { key: 1 },
              [
                createVNode(_component_aicode_divider),
                createElementVNode("button", {
                  class: "setting-line",
                  type: "button",
                  onClick: openTtsSheet
                }, [
                  createElementVNode("span", _hoisted_8, [
                    _cache[49] || (_cache[49] = createElementVNode(
                      "span",
                      { class: "setting-title" },
                      "语音合成（TTS）",
                      -1
                      /* CACHED */
                    )),
                    createElementVNode(
                      "span",
                      _hoisted_9,
                      toDisplayString(ttsSubtitle.value),
                      1
                      /* TEXT */
                    )
                  ]),
                  _cache[50] || (_cache[50] = createElementVNode(
                    "span",
                    { class: "setting-action" },
                    "配置",
                    -1
                    /* CACHED */
                  ))
                ])
              ],
              64
              /* STABLE_FRAGMENT */
            )) : createCommentVNode("v-if", true),
            createElementVNode("div", _hoisted_10, [
              createVNode(_component_aicode_button, {
                variant: "primary",
                disabled: saving.value,
                onClick: save
              }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(saving.value ? "保存中…" : "保存设置"),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"]),
              createVNode(_component_aicode_button, {
                disabled: busy.value,
                onClick: sayHello
              }, {
                default: withCtx(() => [..._cache[51] || (_cache[51] = [
                  createTextVNode(
                    "让它说句话",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"])
            ])
          ]),
          _: 1
          /* STABLE */
        }),
        createVNode(_component_aicode_group, { title: "运行状态联动" }, {
          default: withCtx(() => [
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.workStatusEnabled,
              "onUpdate:modelValue": [
                _cache[7] || (_cache[7] = ($event) => settings.value.workStatusEnabled = $event),
                save
              ],
              title: "跟随 AI 运行状态",
              subtitle: "思考、工具执行、完成或出错时切换动作"
            }, null, 8, ["modelValue"]),
            createVNode(_component_aicode_divider),
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.notifyOnRunFinished,
              "onUpdate:modelValue": [
                _cache[8] || (_cache[8] = ($event) => settings.value.notifyOnRunFinished = $event),
                save
              ],
              title: "任务完成后通知",
              subtitle: "AI 一轮对话结束且成功时发送系统通知"
            }, null, 8, ["modelValue"]),
            createVNode(_component_aicode_divider),
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.notifyOnToolError,
              "onUpdate:modelValue": [
                _cache[9] || (_cache[9] = ($event) => settings.value.notifyOnToolError = $event),
                save
              ],
              title: "任务异常时通知",
              subtitle: "失败、取消或工具出错时发送系统通知"
            }, null, 8, ["modelValue"])
          ]),
          _: 1
          /* STABLE */
        }),
        createVNode(_component_aicode_group, { title: "气泡" }, {
          default: withCtx(() => [
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.idleTurn,
              "onUpdate:modelValue": [
                _cache[10] || (_cache[10] = ($event) => settings.value.idleTurn = $event),
                save
              ],
              title: "空闲时东张西望",
              subtitle: "没有任务时偶尔换成左右张望的待机动作"
            }, null, 8, ["modelValue"]),
            createVNode(_component_aicode_divider),
            createElementVNode("div", _hoisted_11, [
              createElementVNode("div", _hoisted_12, [
                _cache[52] || (_cache[52] = createElementVNode(
                  "span",
                  null,
                  "气泡停留时间",
                  -1
                  /* CACHED */
                )),
                createElementVNode(
                  "span",
                  _hoisted_13,
                  toDisplayString(Math.round(settings.value.bubbleDurationMs / 1e3)) + " 秒",
                  1
                  /* TEXT */
                )
              ]),
              withDirectives(createElementVNode(
                "input",
                {
                  "onUpdate:modelValue": _cache[11] || (_cache[11] = ($event) => settings.value.bubbleDurationMs = $event),
                  type: "range",
                  min: "1500",
                  max: "15000",
                  step: "500",
                  onChange: save
                },
                null,
                544
                /* NEED_HYDRATION, NEED_PATCH */
              ), [
                [
                  vModelText,
                  settings.value.bubbleDurationMs,
                  void 0,
                  { number: true }
                ]
              ])
            ]),
            createVNode(_component_aicode_divider),
            createVNode(unref(SettingSwitch), {
              modelValue: settings.value.idleWhisper,
              "onUpdate:modelValue": [
                _cache[12] || (_cache[12] = ($event) => settings.value.idleWhisper = $event),
                save
              ],
              title: "自动碎碎念",
              subtitle: "空闲时按固定间隔说一句"
            }, null, 8, ["modelValue"]),
            createVNode(_component_aicode_divider),
            createVNode(_component_aicode_field, { label: "碎碎念间隔（分钟）" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_input, {
                  modelValue: settings.value.whisperIntervalMinutes,
                  "onUpdate:modelValue": _cache[13] || (_cache[13] = ($event) => settings.value.whisperIntervalMinutes = $event),
                  modelModifiers: { number: true },
                  type: "number",
                  onBlur: save
                }, null, 8, ["modelValue"])
              ]),
              _: 1
              /* STABLE */
            })
          ]),
          _: 1
          /* STABLE */
        }),
        createVNode(_component_aicode_group, { title: "音乐搜索" }, {
          default: withCtx(() => [
            createElementVNode("div", _hoisted_14, [
              withDirectives(createElementVNode(
                "input",
                {
                  "onUpdate:modelValue": _cache[14] || (_cache[14] = ($event) => musicKeywords.value = $event),
                  class: "music-input",
                  type: "search",
                  placeholder: "搜索歌曲、歌手",
                  enterkeyhint: "search",
                  onKeyup: _cache[15] || (_cache[15] = withKeys(($event) => searchMusic(1), ["enter"]))
                },
                null,
                544
                /* NEED_HYDRATION, NEED_PATCH */
              ), [
                [vModelText, musicKeywords.value]
              ]),
              createVNode(_component_aicode_button, {
                disabled: musicLoading.value || !musicKeywords.value.trim(),
                onClick: _cache[16] || (_cache[16] = ($event) => searchMusic(1))
              }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(musicLoading.value ? "搜索中" : "搜索"),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"])
            ]),
            createElementVNode("button", {
              class: "music-account-line",
              type: "button",
              onClick: openMusicAccount
            }, [
              createElementVNode("span", _hoisted_15, [
                _cache[53] || (_cache[53] = createElementVNode(
                  "span",
                  { class: "music-account-title" },
                  "音乐账号",
                  -1
                  /* CACHED */
                )),
                createElementVNode(
                  "span",
                  _hoisted_16,
                  toDisplayString(musicAccount.value ? musicAccount.value.nickname : "未登录（搜索无需登录）"),
                  1
                  /* TEXT */
                )
              ]),
              createElementVNode(
                "span",
                _hoisted_17,
                toDisplayString(musicAccount.value ? "管理" : "登录"),
                1
                /* TEXT */
              )
            ]),
            musicHint.value ? (openBlock(), createElementBlock(
              "p",
              _hoisted_18,
              toDisplayString(musicHint.value),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true),
            musicSongs.value.length ? (openBlock(), createElementBlock("div", _hoisted_19, [
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(musicSongs.value, (song) => {
                  return openBlock(), createElementBlock("div", {
                    key: song.hash,
                    class: "music-item"
                  }, [
                    song.cover ? (openBlock(), createElementBlock("img", {
                      key: 0,
                      class: "music-cover",
                      src: song.cover,
                      alt: "",
                      loading: "lazy"
                    }, null, 8, _hoisted_20)) : (openBlock(), createElementBlock("div", _hoisted_21)),
                    createElementVNode("div", _hoisted_22, [
                      createElementVNode(
                        "span",
                        _hoisted_23,
                        toDisplayString(song.title),
                        1
                        /* TEXT */
                      ),
                      createElementVNode(
                        "span",
                        _hoisted_24,
                        toDisplayString(song.singer) + " · " + toDisplayString(song.album || "未知专辑"),
                        1
                        /* TEXT */
                      ),
                      createElementVNode("span", _hoisted_25, [
                        createTextVNode(
                          toDisplayString(formatMusicDuration(song.duration)),
                          1
                          /* TEXT */
                        ),
                        song.bitrate ? (openBlock(), createElementBlock(
                          Fragment,
                          { key: 0 },
                          [
                            createTextVNode(
                              " · " + toDisplayString(song.bitrate) + "kbps",
                              1
                              /* TEXT */
                            )
                          ],
                          64
                          /* STABLE_FRAGMENT */
                        )) : createCommentVNode("v-if", true)
                      ])
                    ]),
                    createElementVNode("button", {
                      class: "music-play",
                      type: "button",
                      disabled: musicBusy.value,
                      onClick: ($event) => playSongItem(song)
                    }, "▶", 8, _hoisted_26),
                    createElementVNode("button", {
                      class: normalizeClass(["music-fav", { on: favoriteHashes.value.includes(song.hash) }]),
                      type: "button",
                      onClick: ($event) => toggleFavorite(song)
                    }, toDisplayString(favoriteHashes.value.includes(song.hash) ? "★" : "☆"), 11, _hoisted_27)
                  ]);
                }),
                128
                /* KEYED_FRAGMENT */
              )),
              createElementVNode("div", _hoisted_28, [
                createVNode(_component_aicode_button, {
                  disabled: musicLoading.value || musicPage.value <= 1,
                  onClick: _cache[17] || (_cache[17] = ($event) => searchMusic(musicPage.value - 1))
                }, {
                  default: withCtx(() => [..._cache[54] || (_cache[54] = [
                    createTextVNode(
                      "上一页",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["disabled"]),
                createElementVNode(
                  "span",
                  _hoisted_29,
                  "第 " + toDisplayString(musicPage.value) + " 页",
                  1
                  /* TEXT */
                ),
                createVNode(_component_aicode_button, {
                  disabled: musicLoading.value,
                  onClick: _cache[18] || (_cache[18] = ($event) => searchMusic(musicPage.value + 1))
                }, {
                  default: withCtx(() => [..._cache[55] || (_cache[55] = [
                    createTextVNode(
                      "下一页",
                      -1
                      /* CACHED */
                    )
                  ])]),
                  _: 1
                  /* STABLE */
                }, 8, ["disabled"])
              ])
            ])) : createCommentVNode("v-if", true),
            createVNode(_component_aicode_divider),
            createVNode(_component_aicode_field, { label: "接口地址" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_input, {
                  modelValue: musicApiBaseUrl.value,
                  "onUpdate:modelValue": _cache[19] || (_cache[19] = ($event) => musicApiBaseUrl.value = $event),
                  placeholder: "https://music.api.hoilai.cn",
                  onBlur: saveMusicSettings
                }, null, 8, ["modelValue"])
              ]),
              _: 1
              /* STABLE */
            }),
            _cache[61] || (_cache[61] = createElementVNode(
              "p",
              { class: "voice-hint" },
              " 默认接口来自开源项目 kgka_Music_hl 的公开服务，可改为自建地址。 ",
              -1
              /* CACHED */
            )),
            createVNode(_component_aicode_divider),
            createElementVNode("button", {
              class: "music-account-line",
              type: "button",
              onClick: openAccountPlaylists
            }, [
              createElementVNode("span", _hoisted_30, [
                _cache[56] || (_cache[56] = createElementVNode(
                  "span",
                  { class: "music-account-title" },
                  "我的歌单（账号）",
                  -1
                  /* CACHED */
                )),
                createElementVNode(
                  "span",
                  _hoisted_31,
                  toDisplayString(accountPlaylistSub.value),
                  1
                  /* TEXT */
                )
              ]),
              _cache[57] || (_cache[57] = createElementVNode(
                "span",
                { class: "music-account-action" },
                "查看",
                -1
                /* CACHED */
              ))
            ]),
            createElementVNode("button", {
              class: "music-account-line",
              type: "button",
              onClick: openFavorites
            }, [
              createElementVNode("span", _hoisted_32, [
                _cache[58] || (_cache[58] = createElementVNode(
                  "span",
                  { class: "music-account-title" },
                  "收藏歌单",
                  -1
                  /* CACHED */
                )),
                createElementVNode(
                  "span",
                  _hoisted_33,
                  toDisplayString(favoriteSummaryText.value),
                  1
                  /* TEXT */
                )
              ]),
              _cache[59] || (_cache[59] = createElementVNode(
                "span",
                { class: "music-account-action" },
                "管理",
                -1
                /* CACHED */
              ))
            ]),
            createElementVNode("div", _hoisted_34, [
              createVNode(_component_aicode_button, {
                disabled: musicBusy.value || favoriteTotalCount.value === 0,
                onClick: singFromPet
              }, {
                default: withCtx(() => [..._cache[60] || (_cache[60] = [
                  createTextVNode(
                    "让桌宠唱一首",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"])
            ])
          ]),
          _: 1
          /* STABLE */
        }),
        createVNode(_component_aicode_group, { title: "互动与快捷操作" }, {
          default: withCtx(() => [
            createElementVNode("div", _hoisted_35, [
              createVNode(_component_aicode_button, {
                disabled: busy.value,
                onClick: _cache[20] || (_cache[20] = ($event) => interact("headpat"))
              }, {
                default: withCtx(() => [..._cache[62] || (_cache[62] = [
                  createTextVNode(
                    "摸摸头",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"]),
              createVNode(_component_aicode_button, {
                disabled: busy.value,
                onClick: _cache[21] || (_cache[21] = ($event) => interact("feed"))
              }, {
                default: withCtx(() => [..._cache[63] || (_cache[63] = [
                  createTextVNode(
                    "喂点心",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"]),
              createVNode(_component_aicode_button, {
                disabled: busy.value,
                onClick: playAction
              }, {
                default: withCtx(() => [..._cache[64] || (_cache[64] = [
                  createTextVNode(
                    "播放动作",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"]),
              createVNode(_component_aicode_button, {
                disabled: busy.value,
                onClick: toggleSleep
              }, {
                default: withCtx(() => [
                  createTextVNode(
                    toDisplayString(sleeping.value ? "叫醒桌宠" : "哄它睡觉"),
                    1
                    /* TEXT */
                  )
                ]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"]),
              settings.value.pet.enabled ? (openBlock(), createBlock(_component_aicode_button, {
                key: 0,
                disabled: busy.value,
                onClick: hidePet
              }, {
                default: withCtx(() => [..._cache[65] || (_cache[65] = [
                  createTextVNode(
                    "隐藏桌宠",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"])) : (openBlock(), createBlock(_component_aicode_button, {
                key: 1,
                disabled: busy.value,
                onClick: showPet
              }, {
                default: withCtx(() => [..._cache[66] || (_cache[66] = [
                  createTextVNode(
                    "显示桌宠",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"]))
            ]),
            createVNode(_component_aicode_divider),
            createVNode(_component_aicode_info_row, {
              label: "当前状态",
              value: statusSubtitle.value
            }, null, 8, ["value"]),
            createVNode(_component_aicode_divider),
            createVNode(_component_aicode_info_row, {
              label: "心情值",
              value: `${petState.value.mood} / 100`
            }, null, 8, ["value"]),
            createVNode(_component_aicode_divider),
            createVNode(_component_aicode_info_row, {
              label: "插件数据",
              value: ctx.value ? ctx.value.dataDir : "加载中…"
            }, null, 8, ["value"]),
            createVNode(_component_aicode_divider),
            createVNode(_component_aicode_info_row, {
              label: "操作方式",
              value: "点击回应、长按打开菜单、拖动换位置"
            })
          ]),
          _: 1
          /* STABLE */
        }),
        createElementVNode("div", _hoisted_36, [
          createVNode(_component_aicode_button, {
            disabled: busy.value,
            onClick: reset
          }, {
            default: withCtx(() => [..._cache[67] || (_cache[67] = [
              createTextVNode(
                "恢复默认设置",
                -1
                /* CACHED */
              )
            ])]),
            _: 1
            /* STABLE */
          }, 8, ["disabled"]),
          createVNode(_component_aicode_button, {
            variant: "danger",
            disabled: busy.value,
            onClick: _cache[22] || (_cache[22] = ($event) => confirmOpen.value = true)
          }, {
            default: withCtx(() => [..._cache[68] || (_cache[68] = [
              createTextVNode(
                "重置并隐藏",
                -1
                /* CACHED */
              )
            ])]),
            _: 1
            /* STABLE */
          }, 8, ["disabled"])
        ]),
        createVNode(_component_aicode_dialog, {
          modelValue: musicAccountOpen.value,
          "onUpdate:modelValue": _cache[26] || (_cache[26] = ($event) => musicAccountOpen.value = $event),
          title: "音乐账号",
          onConfirm: _cache[27] || (_cache[27] = ($event) => musicAccountOpen.value = false)
        }, {
          default: withCtx(() => [
            musicAccount.value ? (openBlock(), createElementBlock(
              Fragment,
              { key: 0 },
              [
                createElementVNode("div", _hoisted_37, [
                  musicAccount.value.avatarUrl ? (openBlock(), createElementBlock("img", {
                    key: 0,
                    class: "music-avatar",
                    src: musicAccount.value.avatarUrl,
                    alt: ""
                  }, null, 8, _hoisted_38)) : createCommentVNode("v-if", true),
                  createElementVNode("div", null, [
                    createElementVNode(
                      "div",
                      _hoisted_39,
                      toDisplayString(musicAccount.value.nickname),
                      1
                      /* TEXT */
                    ),
                    createElementVNode(
                      "div",
                      _hoisted_40,
                      "ID " + toDisplayString(musicAccount.value.userId || "未知"),
                      1
                      /* TEXT */
                    )
                  ])
                ]),
                createElementVNode("div", _hoisted_41, [
                  createVNode(_component_aicode_button, {
                    disabled: musicBusy.value,
                    onClick: logoutMusic
                  }, {
                    default: withCtx(() => [..._cache[69] || (_cache[69] = [
                      createTextVNode(
                        "退出登录",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }, 8, ["disabled"])
                ])
              ],
              64
              /* STABLE_FRAGMENT */
            )) : (openBlock(), createElementBlock(
              Fragment,
              { key: 1 },
              [
                createElementVNode("div", _hoisted_42, [
                  createElementVNode(
                    "button",
                    {
                      class: normalizeClass(["music-tab", { active: musicTab.value === "qr" }]),
                      type: "button",
                      onClick: openMusicQr
                    },
                    "扫码登录",
                    2
                    /* CLASS */
                  ),
                  createElementVNode(
                    "button",
                    {
                      class: normalizeClass(["music-tab", { active: musicTab.value === "phone" }]),
                      type: "button",
                      onClick: _cache[23] || (_cache[23] = ($event) => musicTab.value = "phone")
                    },
                    "手机号",
                    2
                    /* CLASS */
                  )
                ]),
                musicTab.value === "qr" ? (openBlock(), createElementBlock(
                  Fragment,
                  { key: 0 },
                  [
                    createElementVNode("div", _hoisted_43, [
                      musicQrImage.value ? (openBlock(), createElementBlock("img", {
                        key: 0,
                        class: "music-qr",
                        src: musicQrImage.value,
                        alt: "登录二维码"
                      }, null, 8, _hoisted_44)) : (openBlock(), createElementBlock("span", _hoisted_45, "正在获取二维码…"))
                    ]),
                    createElementVNode(
                      "p",
                      _hoisted_46,
                      toDisplayString(musicQrHint.value),
                      1
                      /* TEXT */
                    )
                  ],
                  64
                  /* STABLE_FRAGMENT */
                )) : (openBlock(), createElementBlock(
                  Fragment,
                  { key: 1 },
                  [
                    createVNode(_component_aicode_field, { label: "手机号" }, {
                      default: withCtx(() => [
                        createVNode(_component_aicode_input, {
                          modelValue: musicMobile.value,
                          "onUpdate:modelValue": _cache[24] || (_cache[24] = ($event) => musicMobile.value = $event),
                          placeholder: "11 位手机号"
                        }, null, 8, ["modelValue"])
                      ]),
                      _: 1
                      /* STABLE */
                    }),
                    createVNode(_component_aicode_field, { label: "验证码" }, {
                      default: withCtx(() => [
                        createVNode(_component_aicode_input, {
                          modelValue: musicCode.value,
                          "onUpdate:modelValue": _cache[25] || (_cache[25] = ($event) => musicCode.value = $event),
                          placeholder: "短信验证码"
                        }, null, 8, ["modelValue"])
                      ]),
                      _: 1
                      /* STABLE */
                    }),
                    createElementVNode("div", _hoisted_47, [
                      createVNode(_component_aicode_button, {
                        disabled: musicBusy.value || !musicMobile.value.trim(),
                        onClick: sendMusicCode
                      }, {
                        default: withCtx(() => [..._cache[70] || (_cache[70] = [
                          createTextVNode(
                            "发送验证码",
                            -1
                            /* CACHED */
                          )
                        ])]),
                        _: 1
                        /* STABLE */
                      }, 8, ["disabled"]),
                      createVNode(_component_aicode_button, {
                        variant: "primary",
                        disabled: musicBusy.value || !musicMobile.value.trim() || !musicCode.value.trim(),
                        onClick: loginMusicByPhone
                      }, {
                        default: withCtx(() => [..._cache[71] || (_cache[71] = [
                          createTextVNode(
                            " 登录 ",
                            -1
                            /* CACHED */
                          )
                        ])]),
                        _: 1
                        /* STABLE */
                      }, 8, ["disabled"])
                    ])
                  ],
                  64
                  /* STABLE_FRAGMENT */
                ))
              ],
              64
              /* STABLE_FRAGMENT */
            )),
            musicLoginHint.value ? (openBlock(), createElementBlock(
              "p",
              _hoisted_48,
              toDisplayString(musicLoginHint.value),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true)
          ]),
          _: 1
          /* STABLE */
        }, 8, ["modelValue"]),
        createVNode(_component_aicode_dialog, {
          modelValue: accountListsOpen.value,
          "onUpdate:modelValue": _cache[28] || (_cache[28] = ($event) => accountListsOpen.value = $event),
          title: "我的歌单",
          onConfirm: _cache[29] || (_cache[29] = ($event) => accountListsOpen.value = false)
        }, {
          default: withCtx(() => [
            !musicAccount.value ? (openBlock(), createElementBlock("p", _hoisted_49, "未登录：账号歌单需要先登录才能读取。")) : (openBlock(), createElementBlock(
              Fragment,
              { key: 1 },
              [
                accountListHint.value ? (openBlock(), createElementBlock(
                  "p",
                  _hoisted_50,
                  toDisplayString(accountListHint.value),
                  1
                  /* TEXT */
                )) : createCommentVNode("v-if", true),
                accountPlaylists.value.length ? (openBlock(), createElementBlock("div", _hoisted_51, [
                  (openBlock(true), createElementBlock(
                    Fragment,
                    null,
                    renderList(accountPlaylists.value, (list) => {
                      return openBlock(), createElementBlock("button", {
                        key: list.id,
                        class: "music-account-line",
                        type: "button",
                        onClick: ($event) => openAccountPlaylist(list)
                      }, [
                        list.cover ? (openBlock(), createElementBlock("img", {
                          key: 0,
                          class: "music-cover",
                          src: list.cover,
                          alt: "",
                          loading: "lazy"
                        }, null, 8, _hoisted_53)) : (openBlock(), createElementBlock("div", _hoisted_54)),
                        createElementVNode("span", _hoisted_55, [
                          createElementVNode(
                            "span",
                            _hoisted_56,
                            toDisplayString(list.name),
                            1
                            /* TEXT */
                          ),
                          createElementVNode(
                            "span",
                            _hoisted_57,
                            toDisplayString(list.songCount) + " 首" + toDisplayString(list.isDefault ? " · 我喜欢" : ""),
                            1
                            /* TEXT */
                          )
                        ]),
                        _cache[72] || (_cache[72] = createElementVNode(
                          "span",
                          { class: "music-account-action" },
                          "›",
                          -1
                          /* CACHED */
                        ))
                      ], 8, _hoisted_52);
                    }),
                    128
                    /* KEYED_FRAGMENT */
                  ))
                ])) : (openBlock(), createElementBlock("p", _hoisted_58, "账号里没有读到歌单。若刚登录，先刷新一次。")),
                createElementVNode("div", _hoisted_59, [
                  createVNode(_component_aicode_button, {
                    disabled: musicBusy.value,
                    onClick: loadAccountPlaylists
                  }, {
                    default: withCtx(() => [..._cache[73] || (_cache[73] = [
                      createTextVNode(
                        "刷新",
                        -1
                        /* CACHED */
                      )
                    ])]),
                    _: 1
                    /* STABLE */
                  }, 8, ["disabled"])
                ])
              ],
              64
              /* STABLE_FRAGMENT */
            ))
          ]),
          _: 1
          /* STABLE */
        }, 8, ["modelValue"]),
        createVNode(_component_aicode_dialog, {
          modelValue: accountSongsOpen.value,
          "onUpdate:modelValue": _cache[30] || (_cache[30] = ($event) => accountSongsOpen.value = $event),
          title: currentAccountList.value ? currentAccountList.value.name : "歌单",
          onConfirm: _cache[31] || (_cache[31] = ($event) => accountSongsOpen.value = false)
        }, {
          default: withCtx(() => [
            accountSongHint.value ? (openBlock(), createElementBlock(
              "p",
              _hoisted_60,
              toDisplayString(accountSongHint.value),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true),
            accountSongs.value.length ? (openBlock(), createElementBlock("div", _hoisted_61, [
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(accountSongs.value, (song) => {
                  return openBlock(), createElementBlock("div", {
                    key: song.hash,
                    class: "music-item"
                  }, [
                    song.cover ? (openBlock(), createElementBlock("img", {
                      key: 0,
                      class: "music-cover",
                      src: song.cover,
                      alt: "",
                      loading: "lazy"
                    }, null, 8, _hoisted_62)) : (openBlock(), createElementBlock("div", _hoisted_63)),
                    createElementVNode("div", _hoisted_64, [
                      createElementVNode(
                        "span",
                        _hoisted_65,
                        toDisplayString(song.title),
                        1
                        /* TEXT */
                      ),
                      createElementVNode(
                        "span",
                        _hoisted_66,
                        toDisplayString(song.singer) + " · " + toDisplayString(song.album || "未知专辑"),
                        1
                        /* TEXT */
                      ),
                      createElementVNode(
                        "span",
                        _hoisted_67,
                        toDisplayString(formatMusicDuration(song.duration)),
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode("button", {
                      class: "music-play",
                      type: "button",
                      disabled: musicBusy.value,
                      onClick: ($event) => playSongItem(song)
                    }, "▶", 8, _hoisted_68),
                    createElementVNode("button", {
                      class: normalizeClass(["music-fav", { on: favoriteHashes.value.includes(song.hash) }]),
                      type: "button",
                      onClick: ($event) => toggleFavorite(song)
                    }, toDisplayString(favoriteHashes.value.includes(song.hash) ? "★" : "☆"), 11, _hoisted_69)
                  ]);
                }),
                128
                /* KEYED_FRAGMENT */
              ))
            ])) : createCommentVNode("v-if", true),
            accountSongs.value.length ? (openBlock(), createElementBlock("div", _hoisted_70, [
              createVNode(_component_aicode_button, {
                disabled: musicBusy.value,
                onClick: singCurrentPlaylist
              }, {
                default: withCtx(() => [..._cache[74] || (_cache[74] = [
                  createTextVNode(
                    "让桌宠从这个歌单唱一首",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"])
            ])) : createCommentVNode("v-if", true)
          ]),
          _: 1
          /* STABLE */
        }, 8, ["modelValue", "title"]),
        createVNode(_component_aicode_dialog, {
          modelValue: favoritesOpen.value,
          "onUpdate:modelValue": _cache[32] || (_cache[32] = ($event) => favoritesOpen.value = $event),
          title: "收藏歌单",
          onConfirm: _cache[33] || (_cache[33] = ($event) => favoritesOpen.value = false)
        }, {
          default: withCtx(() => [
            createElementVNode("div", _hoisted_71, [
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(favoriteLists.value, (list) => {
                  return openBlock(), createElementBlock("button", {
                    key: list.id,
                    class: normalizeClass(["music-tab", { active: currentListId.value === list.id }]),
                    type: "button",
                    onClick: ($event) => selectList(list.id)
                  }, toDisplayString(list.name) + "（" + toDisplayString(list.count) + "） ", 11, _hoisted_72);
                }),
                128
                /* KEYED_FRAGMENT */
              ))
            ]),
            createElementVNode("div", _hoisted_73, [
              createVNode(_component_aicode_button, {
                disabled: musicBusy.value,
                onClick: createFavoriteList
              }, {
                default: withCtx(() => [..._cache[75] || (_cache[75] = [
                  createTextVNode(
                    "新建歌单",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"]),
              currentListId.value ? (openBlock(), createBlock(_component_aicode_button, {
                key: 0,
                disabled: musicBusy.value,
                onClick: removeCurrentList
              }, {
                default: withCtx(() => [..._cache[76] || (_cache[76] = [
                  createTextVNode(
                    "删除歌单",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"])) : createCommentVNode("v-if", true)
            ]),
            favoriteHint.value ? (openBlock(), createElementBlock(
              "p",
              _hoisted_74,
              toDisplayString(favoriteHint.value),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true),
            favoriteSongs.value.length ? (openBlock(), createElementBlock("div", _hoisted_75, [
              (openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(favoriteSongs.value, (song) => {
                  return openBlock(), createElementBlock("div", {
                    key: song.hash,
                    class: "music-item"
                  }, [
                    song.cover ? (openBlock(), createElementBlock("img", {
                      key: 0,
                      class: "music-cover",
                      src: song.cover,
                      alt: "",
                      loading: "lazy"
                    }, null, 8, _hoisted_76)) : (openBlock(), createElementBlock("div", _hoisted_77)),
                    createElementVNode("div", _hoisted_78, [
                      createElementVNode(
                        "span",
                        _hoisted_79,
                        toDisplayString(song.title),
                        1
                        /* TEXT */
                      ),
                      createElementVNode(
                        "span",
                        _hoisted_80,
                        toDisplayString(song.singer) + " · " + toDisplayString(song.album || "未知专辑"),
                        1
                        /* TEXT */
                      )
                    ]),
                    createElementVNode("button", {
                      class: "music-play",
                      type: "button",
                      disabled: musicBusy.value,
                      onClick: ($event) => playSongItem(song)
                    }, "▶", 8, _hoisted_81),
                    createElementVNode("button", {
                      class: "music-fav on",
                      type: "button",
                      onClick: ($event) => removeFavoriteSong(song)
                    }, "★", 8, _hoisted_82)
                  ]);
                }),
                128
                /* KEYED_FRAGMENT */
              ))
            ])) : (openBlock(), createElementBlock("p", _hoisted_83, "这个歌单还没有歌，去搜索里点 ☆ 收藏。"))
          ]),
          _: 1
          /* STABLE */
        }, 8, ["modelValue"]),
        createVNode(_component_aicode_dialog, {
          modelValue: confirmOpen.value,
          "onUpdate:modelValue": _cache[34] || (_cache[34] = ($event) => confirmOpen.value = $event),
          title: "恢复默认设置",
          message: "会重置所有外观、人设和通知选项，桌宠浮层也会按默认配置重新创建。",
          onConfirm: reset
        }, null, 8, ["modelValue"]),
        createVNode(_component_aicode_dialog, {
          modelValue: modelPickerOpen.value,
          "onUpdate:modelValue": _cache[37] || (_cache[37] = ($event) => modelPickerOpen.value = $event),
          title: "选择说话用的模型",
          "confirm-text": "确定",
          "confirm-disabled": voiceDraft.value.providerId === "",
          onConfirm: applyModelChoice
        }, {
          default: withCtx(() => [
            createVNode(_component_aicode_field, { label: "供应商" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_select, {
                  modelValue: voiceDraft.value.providerId,
                  "onUpdate:modelValue": [
                    _cache[35] || (_cache[35] = ($event) => voiceDraft.value.providerId = $event),
                    onProviderChange
                  ],
                  options: providerOptions.value
                }, null, 8, ["modelValue", "options"])
              ]),
              _: 1
              /* STABLE */
            }),
            createVNode(_component_aicode_field, { label: "模型" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_select, {
                  modelValue: voiceDraft.value.model,
                  "onUpdate:modelValue": _cache[36] || (_cache[36] = ($event) => voiceDraft.value.model = $event),
                  options: modelOptions.value
                }, null, 8, ["modelValue", "options"])
              ]),
              _: 1
              /* STABLE */
            }),
            voiceHint.value ? (openBlock(), createElementBlock(
              "p",
              _hoisted_84,
              toDisplayString(voiceHint.value),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true)
          ]),
          _: 1
          /* STABLE */
        }, 8, ["modelValue", "confirm-disabled"]),
        createVNode(_component_aicode_dialog, {
          modelValue: ttsOpen.value,
          "onUpdate:modelValue": _cache[44] || (_cache[44] = ($event) => ttsOpen.value = $event),
          title: "语音合成（TTS）",
          "confirm-text": "保存",
          onConfirm: saveTts
        }, {
          default: withCtx(() => [
            createVNode(_component_aicode_field, { label: "供应商" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_select, {
                  modelValue: ttsDraft.value.providerId,
                  "onUpdate:modelValue": [
                    _cache[38] || (_cache[38] = ($event) => ttsDraft.value.providerId = $event),
                    onTtsProviderPick
                  ],
                  options: ttsProviderPickerOptions.value
                }, null, 8, ["modelValue", "options"])
              ]),
              _: 1
              /* STABLE */
            }),
            !ttsDraft.value.providerId ? (openBlock(), createElementBlock("p", _hoisted_85, " 选「自定义」可填任意兼容服务的地址与密钥，不要求在 AiCode 里预先配置。 ")) : createCommentVNode("v-if", true),
            createVNode(_component_aicode_field, { label: "模型" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_select, {
                  modelValue: ttsModelPick.value,
                  "onUpdate:modelValue": [
                    _cache[39] || (_cache[39] = ($event) => ttsModelPick.value = $event),
                    onTtsModelPick
                  ],
                  options: ttsModelOptions.value
                }, null, 8, ["modelValue", "options"])
              ]),
              _: 1
              /* STABLE */
            }),
            ttsModelPick.value === "__manual__" ? (openBlock(), createBlock(_component_aicode_field, {
              key: 1,
              label: "模型名"
            }, {
              default: withCtx(() => [
                createVNode(_component_aicode_input, {
                  modelValue: ttsDraft.value.model,
                  "onUpdate:modelValue": _cache[40] || (_cache[40] = ($event) => ttsDraft.value.model = $event),
                  placeholder: ttsModelPlaceholder.value
                }, null, 8, ["modelValue", "placeholder"])
              ]),
              _: 1
              /* STABLE */
            })) : createCommentVNode("v-if", true),
            createElementVNode(
              "p",
              _hoisted_86,
              toDisplayString(ttsModelHint.value),
              1
              /* TEXT */
            ),
            createVNode(_component_aicode_field, { label: "音色" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_input, {
                  modelValue: ttsDraft.value.voice,
                  "onUpdate:modelValue": _cache[41] || (_cache[41] = ($event) => ttsDraft.value.voice = $event),
                  placeholder: ttsVoicePlaceholder.value
                }, null, 8, ["modelValue", "placeholder"])
              ]),
              _: 1
              /* STABLE */
            }),
            createVNode(_component_aicode_field, { label: "API 地址（可留空）" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_input, {
                  modelValue: ttsDraft.value.baseUrl,
                  "onUpdate:modelValue": _cache[42] || (_cache[42] = ($event) => ttsDraft.value.baseUrl = $event),
                  placeholder: ttsBaseUrlPlaceholder.value
                }, null, 8, ["modelValue", "placeholder"])
              ]),
              _: 1
              /* STABLE */
            }),
            createVNode(_component_aicode_field, { label: "API Key" }, {
              default: withCtx(() => [
                createVNode(_component_aicode_input, {
                  modelValue: ttsKeyInput.value,
                  "onUpdate:modelValue": _cache[43] || (_cache[43] = ($event) => ttsKeyInput.value = $event),
                  type: "password",
                  placeholder: ttsHasKey.value ? "已保存，留空则不修改" : "填入后保存"
                }, null, 8, ["modelValue", "placeholder"])
              ]),
              _: 1
              /* STABLE */
            }),
            createElementVNode(
              "p",
              _hoisted_87,
              toDisplayString(ttsAddressHint.value),
              1
              /* TEXT */
            ),
            createElementVNode("div", _hoisted_88, [
              createVNode(_component_aicode_button, {
                disabled: busy.value,
                onClick: previewTts
              }, {
                default: withCtx(() => [..._cache[77] || (_cache[77] = [
                  createTextVNode(
                    "试听",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"]),
              settings.value.voice.tts.provider !== "none" ? (openBlock(), createBlock(_component_aicode_button, {
                key: 0,
                disabled: busy.value,
                onClick: disableTts
              }, {
                default: withCtx(() => [..._cache[78] || (_cache[78] = [
                  createTextVNode(
                    "关闭朗读",
                    -1
                    /* CACHED */
                  )
                ])]),
                _: 1
                /* STABLE */
              }, 8, ["disabled"])) : createCommentVNode("v-if", true)
            ]),
            ttsHint.value ? (openBlock(), createElementBlock(
              "p",
              _hoisted_89,
              toDisplayString(ttsHint.value),
              1
              /* TEXT */
            )) : createCommentVNode("v-if", true)
          ]),
          _: 1
          /* STABLE */
        }, 8, ["modelValue"])
      ]);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const App = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a5c7e781"]]);
const app = createApp(App);
if (window.AicodeUI) app.use(window.AicodeUI);
app.mount("#app");
