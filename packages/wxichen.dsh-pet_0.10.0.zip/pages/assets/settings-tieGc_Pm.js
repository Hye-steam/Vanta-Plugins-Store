(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const Vue = window.Vue;
if (!Vue) throw new Error("Aicode page requires /__aicode/vue.global.prod.js");
Vue.BaseTransition;
Vue.BaseTransitionPropsValidators;
Vue.Comment;
Vue.DeprecationTypes;
Vue.EffectScope;
Vue.ErrorCodes;
Vue.ErrorTypeStrings;
const Fragment = Vue.Fragment;
Vue.KeepAlive;
Vue.ReactiveEffect;
Vue.Static;
Vue.Suspense;
Vue.Teleport;
Vue.Text;
Vue.TrackOpTypes;
const Transition = Vue.Transition;
Vue.TransitionGroup;
Vue.TriggerOpTypes;
Vue.VueElement;
Vue.__esModule;
Vue.assertNumber;
Vue.callWithAsyncErrorHandling;
Vue.callWithErrorHandling;
Vue.camelize;
Vue.capitalize;
Vue.cloneVNode;
Vue.compatUtils;
Vue.compile;
const computed = Vue.computed;
const createApp = Vue.createApp;
const createBlock = Vue.createBlock;
const createCommentVNode = Vue.createCommentVNode;
const createElementBlock = Vue.createElementBlock;
const createElementVNode = Vue.createElementVNode;
Vue.createHydrationRenderer;
Vue.createPropsRestProxy;
Vue.createRenderer;
Vue.createSSRApp;
Vue.createSlots;
Vue.createStaticVNode;
const createTextVNode = Vue.createTextVNode;
const createVNode = Vue.createVNode;
Vue.customRef;
Vue.defineAsyncComponent;
const defineComponent = Vue.defineComponent;
Vue.defineCustomElement;
Vue.defineEmits;
Vue.defineExpose;
Vue.defineModel;
Vue.defineOptions;
Vue.defineProps;
Vue.defineSSRCustomElement;
Vue.defineSlots;
Vue.devtools;
Vue.effect;
Vue.effectScope;
Vue.getCurrentInstance;
Vue.getCurrentScope;
Vue.getCurrentWatcher;
Vue.getTransitionRawChildren;
Vue.guardReactiveProps;
const h = Vue.h;
Vue.handleError;
Vue.hasInjectionContext;
Vue.hydrate;
Vue.hydrateOnIdle;
Vue.hydrateOnInteraction;
Vue.hydrateOnMediaQuery;
Vue.hydrateOnVisible;
Vue.initCustomFormatter;
Vue.initDirectivesForSSR;
Vue.inject;
Vue.isMemoSame;
Vue.isProxy;
Vue.isReactive;
Vue.isReadonly;
Vue.isRef;
Vue.isRuntimeOnly;
Vue.isShallow;
Vue.isVNode;
Vue.markRaw;
Vue.mergeDefaults;
Vue.mergeModels;
Vue.mergeProps;
const nextTick = Vue.nextTick;
Vue.nodeOps;
const normalizeClass = Vue.normalizeClass;
Vue.normalizeProps;
const normalizeStyle = Vue.normalizeStyle;
Vue.onActivated;
Vue.onBeforeMount;
const onBeforeUnmount = Vue.onBeforeUnmount;
Vue.onBeforeUpdate;
Vue.onDeactivated;
Vue.onErrorCaptured;
const onMounted = Vue.onMounted;
Vue.onRenderTracked;
Vue.onRenderTriggered;
Vue.onScopeDispose;
Vue.onServerPrefetch;
Vue.onUnmounted;
Vue.onUpdated;
Vue.onWatcherCleanup;
const openBlock = Vue.openBlock;
Vue.patchProp;
Vue.popScopeId;
Vue.provide;
Vue.proxyRefs;
Vue.pushScopeId;
Vue.queuePostFlushCb;
Vue.reactive;
Vue.readonly;
const ref = Vue.ref;
Vue.registerRuntimeCompiler;
Vue.render;
const renderList = Vue.renderList;
Vue.renderSlot;
const resolveComponent = Vue.resolveComponent;
Vue.resolveDirective;
Vue.resolveDynamicComponent;
Vue.resolveFilter;
Vue.resolveTransitionHooks;
Vue.setBlockTracking;
Vue.setDevtoolsHook;
Vue.setTransitionHooks;
Vue.shallowReactive;
Vue.shallowReadonly;
Vue.shallowRef;
Vue.ssrContextKey;
Vue.ssrUtils;
Vue.stop;
const toDisplayString = Vue.toDisplayString;
Vue.toHandlerKey;
Vue.toHandlers;
Vue.toRaw;
Vue.toRef;
Vue.toRefs;
Vue.toValue;
Vue.transformVNodeArgs;
Vue.triggerRef;
const unref = Vue.unref;
Vue.useAttrs;
Vue.useCssModule;
Vue.useCssVars;
Vue.useHost;
Vue.useId;
Vue.useModel;
Vue.useSSRContext;
Vue.useShadowRoot;
Vue.useSlots;
Vue.useTemplateRef;
Vue.useTransitionState;
Vue.vModelCheckbox;
Vue.vModelDynamic;
Vue.vModelRadio;
Vue.vModelSelect;
const vModelText = Vue.vModelText;
Vue.vShow;
Vue.version;
Vue.warn;
Vue.watch;
Vue.watchEffect;
Vue.watchPostEffect;
Vue.watchSyncEffect;
Vue.withAsyncContext;
const withCtx = Vue.withCtx;
Vue.withDefaults;
const withDirectives = Vue.withDirectives;
const withKeys = Vue.withKeys;
Vue.withMemo;
Vue.withModifiers;
Vue.withScopeId;
const DEFAULT_MUSIC_SETTINGS = {
  apiBaseUrl: "https://music.api.hoilai.cn",
  pageSize: 30
};
const MAX_BASE_URL = 2048;
function normalizeBaseUrl(raw) {
  if (typeof raw !== "string") return DEFAULT_MUSIC_SETTINGS.apiBaseUrl;
  const value = raw.trim().replace(/\/+$/, "");
  if (!value || value.length > MAX_BASE_URL) return DEFAULT_MUSIC_SETTINGS.apiBaseUrl;
  if (!/^https?:\/\//i.test(value)) return DEFAULT_MUSIC_SETTINGS.apiBaseUrl;
  return value;
}
function normalizeMusicSettings(raw) {
  const input = raw && typeof raw === "object" ? raw : {};
  const size = typeof input.pageSize === "number" && Number.isFinite(input.pageSize) ? input.pageSize : DEFAULT_MUSIC_SETTINGS.pageSize;
  return {
    apiBaseUrl: normalizeBaseUrl(input.apiBaseUrl),
    pageSize: Math.min(50, Math.max(1, Math.round(size)))
  };
}
const DEFAULT_SETTINGS = {
  pet: {
    enabled: true,
    autoStart: true,
    size: 200,
    alwaysOnTop: true,
    clickSound: false
  },
  petName: "蓝毛小女仆",
  persona: "你是主人手机上的 Q 版蓝发小女仆桌宠。说话温柔、俏皮、简短，不提自己是 AI。",
  voice: {
    mode: "auto",
    providerId: "",
    model: "",
    speakAloud: false,
    tts: {
      provider: "none",
      providerId: "",
      baseUrl: "",
      model: "",
      voice: "",
      hasKey: false,
      speed: 1
    }
  },
  bubbleDurationMs: 6e3,
  idleWhisper: false,
  whisperIntervalMinutes: 30,
  idleTurn: true,
  notifyOnRunFinished: true,
  notifyOnToolError: true,
  workStatusEnabled: true,
  music: {
    apiBaseUrl: "https://music.api.hoilai.cn",
    pageSize: 30
  },
  animations: {
    idle: "idle",
    turn: "turn",
    click: "click",
    drag: "drag",
    action: "action",
    work: "thinking",
    busy: "working",
    success: "success",
    error: "error"
  }
};
const MOOD_DEFAULT = 70;
const CLAMP_MIN = 140;
const CLAMP_MAX = 320;
function readNumber(value, fallback) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
function readBoolean(value, fallback) {
  return typeof value === "boolean" ? value : fallback;
}
function readText(value, fallback) {
  return typeof value === "string" && value.trim() ? value : fallback;
}
function readAnimation(value, fallback) {
  const allowed = [
    "idle",
    "turn",
    "click",
    "drag",
    "action",
    "sleepStart",
    "sleepLoop",
    "sleepEnd",
    "thinking",
    "working",
    "success",
    "error",
    "say"
  ];
  return allowed.includes(value) ? value : fallback;
}
function readTtsProvider(value, fallback) {
  return value === "openai" || value === "gemini" || value === "none" ? value : fallback;
}
function normalizeTts(raw) {
  const input = raw && typeof raw === "object" ? raw : {};
  return {
    provider: readTtsProvider(input.provider, DEFAULT_SETTINGS.voice.tts.provider),
    providerId: typeof input.providerId === "string" ? input.providerId : "",
    baseUrl: typeof input.baseUrl === "string" ? input.baseUrl.trim() : "",
    model: typeof input.model === "string" ? input.model.trim() : "",
    voice: typeof input.voice === "string" ? input.voice.trim() : "",
    hasKey: readBoolean(input.hasKey, false),
    speed: Math.min(2, Math.max(0.5, readNumber(input.speed, DEFAULT_SETTINGS.voice.tts.speed)))
  };
}
function normalizeSettings(raw) {
  const input = raw && typeof raw === "object" ? raw : {};
  const petRaw = input.pet && typeof input.pet === "object" ? input.pet : {};
  const voiceRaw = input.voice && typeof input.voice === "object" ? input.voice : {};
  const animationsRaw = input.animations && typeof input.animations === "object" ? input.animations : {};
  return {
    pet: {
      enabled: readBoolean(petRaw.enabled, DEFAULT_SETTINGS.pet.enabled),
      autoStart: readBoolean(petRaw.autoStart, DEFAULT_SETTINGS.pet.autoStart),
      size: Math.min(CLAMP_MAX, Math.max(CLAMP_MIN, Math.round(readNumber(petRaw.size, DEFAULT_SETTINGS.pet.size)))),
      alwaysOnTop: readBoolean(petRaw.alwaysOnTop, DEFAULT_SETTINGS.pet.alwaysOnTop),
      clickSound: readBoolean(petRaw.clickSound, DEFAULT_SETTINGS.pet.clickSound)
    },
    petName: readText(input.petName, DEFAULT_SETTINGS.petName),
    persona: readText(input.persona, DEFAULT_SETTINGS.persona),
    voice: {
      mode: voiceRaw.mode === "canned" ? "canned" : "auto",
      providerId: typeof voiceRaw.providerId === "string" ? voiceRaw.providerId : "",
      model: typeof voiceRaw.model === "string" ? voiceRaw.model : "",
      speakAloud: readBoolean(voiceRaw.speakAloud, DEFAULT_SETTINGS.voice.speakAloud),
      tts: normalizeTts(voiceRaw.tts)
    },
    bubbleDurationMs: Math.min(3e4, Math.max(1500, readNumber(input.bubbleDurationMs, DEFAULT_SETTINGS.bubbleDurationMs))),
    idleWhisper: readBoolean(input.idleWhisper, DEFAULT_SETTINGS.idleWhisper),
    whisperIntervalMinutes: Math.min(720, Math.max(1, readNumber(input.whisperIntervalMinutes, DEFAULT_SETTINGS.whisperIntervalMinutes))),
    idleTurn: readBoolean(input.idleTurn, DEFAULT_SETTINGS.idleTurn),
    notifyOnRunFinished: readBoolean(input.notifyOnRunFinished, DEFAULT_SETTINGS.notifyOnRunFinished),
    notifyOnToolError: readBoolean(input.notifyOnToolError, DEFAULT_SETTINGS.notifyOnToolError),
    workStatusEnabled: readBoolean(input.workStatusEnabled, DEFAULT_SETTINGS.workStatusEnabled),
    music: normalizeMusicSettings(input.music),
    animations: {
      idle: readAnimation(animationsRaw.idle, DEFAULT_SETTINGS.animations.idle),
      turn: readAnimation(animationsRaw.turn, DEFAULT_SETTINGS.animations.turn),
      click: readAnimation(animationsRaw.click, DEFAULT_SETTINGS.animations.click),
      drag: readAnimation(animationsRaw.drag, DEFAULT_SETTINGS.animations.drag),
      action: readAnimation(animationsRaw.action, DEFAULT_SETTINGS.animations.action),
      work: readAnimation(animationsRaw.work, DEFAULT_SETTINGS.animations.work),
      busy: readAnimation(animationsRaw.busy, DEFAULT_SETTINGS.animations.busy),
      success: readAnimation(animationsRaw.success, DEFAULT_SETTINGS.animations.success),
      error: readAnimation(animationsRaw.error, DEFAULT_SETTINGS.animations.error)
    }
  };
}
export {
  DEFAULT_SETTINGS as D,
  Fragment as F,
  MOOD_DEFAULT as M,
  Transition as T,
  ref as a,
  onBeforeUnmount as b,
  computed as c,
  defineComponent as d,
  openBlock as e,
  createElementBlock as f,
  createElementVNode as g,
  h,
  createVNode as i,
  withDirectives as j,
  createCommentVNode as k,
  createTextVNode as l,
  withKeys as m,
  normalizeSettings as n,
  onMounted as o,
  renderList as p,
  normalizeClass as q,
  resolveComponent as r,
  createBlock as s,
  toDisplayString as t,
  unref as u,
  vModelText as v,
  withCtx as w,
  createApp as x,
  normalizeStyle as y,
  nextTick as z
};
