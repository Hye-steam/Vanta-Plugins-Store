import { d as defineComponent, a as ref, M as MOOD_DEFAULT, D as DEFAULT_SETTINGS, c as computed, o as onMounted, b as onBeforeUnmount, e as openBlock, f as createElementBlock, y as normalizeStyle, q as normalizeClass, i as createVNode, T as Transition, w as withCtx, g as createElementVNode, t as toDisplayString, k as createCommentVNode, z as nextTick, n as normalizeSettings, x as createApp } from "./settings-tieGc_Pm.js";
const ANIMATION_ASSETS = {
  idle: { file: "assets/webm/待机呼吸休闲.webm", loop: true },
  turn: { file: "assets/webm/东张西望.webm", loop: true },
  click: { file: "assets/webm/点击回应-开心跃动.webm", loop: false },
  drag: { file: "assets/webm/被鼠标拖拽悬空反馈.webm", loop: true },
  action: { file: "assets/webm/原地专心玩魔方.webm", loop: false },
  sleepStart: { file: "assets/webm/睡觉-开始.webm", loop: false },
  sleepLoop: { file: "assets/webm/睡觉-循环.webm", loop: true },
  sleepEnd: { file: "assets/webm/睡觉-起来.webm", loop: false },
  thinking: { file: "assets/webm/工作状态-思考冒泡.webm", loop: true },
  working: { file: "assets/webm/工作状态-忙碌点按.webm", loop: true },
  success: { file: "assets/webm/工作状态-雀跃庆祝.webm", loop: false },
  error: { file: "assets/webm/工作状态-垂头叹气冒汗.webm", loop: false },
  say: { file: "assets/webm/碎碎念-对屏碎碎念.webm", loop: true }
};
const _hoisted_1 = { class: "bubble-text" };
const _hoisted_2 = {
  key: 0,
  class: "pet-placeholder",
  "aria-hidden": "true"
};
const _hoisted_3 = {
  key: 1,
  class: "sleep-mark",
  "aria-hidden": "true"
};
const BUBBLE_HEIGHT = 40;
const MENU_BUTTON_HEIGHT = 30;
const MENU_BUTTON_MIN_WIDTH = 44;
const MENU_GAP = 4;
const MENU_ITEMS = 5;
const MENU_PADDING = 8;
const MENU_TOP_GAP = 6;
const MENU_RESERVED = 4;
const SIDE_PADDING = 10;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "pet",
  setup(__props) {
    const SLEEP_ANIMATIONS = ["sleepStart", "sleepLoop", "sleepEnd"];
    const state = ref({
      sleeping: false,
      runActive: false,
      toolsActive: 0,
      mood: MOOD_DEFAULT,
      lastAnimation: null,
      lastText: "",
      updatedAt: 0
    });
    const settings = ref(DEFAULT_SETTINGS);
    const bubbleText = ref("");
    const menuOpen = ref(false);
    const dragging = ref(false);
    const activeLayer = ref(-1);
    const stageEl = ref(null);
    const videoA = ref(null);
    const videoB = ref(null);
    let currentAnimation = null;
    let switchSeq = 0;
    let bubbleTimer = null;
    let offMessage = null;
    let lastWidth = 0;
    let lastHeight = 0;
    let pendingResize = false;
    const assetUrls = /* @__PURE__ */ new Map();
    const layerAnimations = [null, null];
    const layerReady = [null, null];
    function videoOf(index) {
      return index === 0 ? videoA.value : videoB.value;
    }
    function resolveAsset(animation) {
      const cached = assetUrls.get(animation);
      if (cached) return cached;
      const asset = ANIMATION_ASSETS[animation];
      const url = new URL("../" + asset.file, window.location.href).href;
      assetUrls.set(animation, url);
      return url;
    }
    const petSize = computed(() => settings.value.pet.size);
    const petHeight = computed(() => Math.round(petSize.value * 9 / 16));
    const windowWidth = computed(() => Math.max(140, Math.min(720, petSize.value + SIDE_PADDING * 2)));
    const stageBottom = computed(() => BUBBLE_HEIGHT + petHeight.value);
    const menuColumns = computed(() => {
      const usable = windowWidth.value - 2 * MENU_PADDING - (MENU_ITEMS - 1) * MENU_GAP;
      return Math.max(1, Math.min(MENU_ITEMS, Math.floor(usable / MENU_BUTTON_MIN_WIDTH)));
    });
    const menuRows = computed(() => Math.ceil(MENU_ITEMS / menuColumns.value));
    const menuHeight = computed(
      () => menuRows.value * MENU_BUTTON_HEIGHT + (menuRows.value - 1) * MENU_GAP + MENU_TOP_GAP
    );
    const windowHeight = computed(
      () => Math.max(120, Math.min(1200, stageBottom.value + (menuOpen.value || dragging.value ? menuHeight.value : MENU_RESERVED)))
    );
    const windowStyle = computed(() => ({
      width: windowWidth.value + "px",
      height: windowHeight.value + "px"
    }));
    const stageStyle = computed(() => ({
      left: SIDE_PADDING + "px",
      top: BUBBLE_HEIGHT + "px",
      width: petSize.value + "px",
      height: petHeight.value + "px"
    }));
    const menuStyle = computed(() => ({
      left: MENU_PADDING + "px",
      right: MENU_PADDING + "px",
      top: stageBottom.value + MENU_TOP_GAP + "px",
      gridTemplateColumns: `repeat(${menuColumns.value}, minmax(0, 1fr))`
    }));
    function idleAnimation() {
      return state.value.mood <= 30 ? settings.value.animations.turn : settings.value.animations.idle;
    }
    function waitReady(video) {
      if (video.readyState >= 2) return Promise.resolve();
      return new Promise((resolve) => {
        const done = () => {
          video.removeEventListener("canplay", done);
          video.removeEventListener("loadeddata", done);
          video.removeEventListener("error", done);
          resolve();
        };
        video.addEventListener("canplay", done, { once: true });
        video.addEventListener("loadeddata", done, { once: true });
        video.addEventListener("error", done, { once: true });
      });
    }
    function prepareLayer(index, animation) {
      const video = videoOf(index);
      if (!video) return Promise.resolve();
      if (layerAnimations[index] === animation && layerReady[index]) return layerReady[index];
      const asset = ANIMATION_ASSETS[animation];
      const url = resolveAsset(animation);
      layerAnimations[index] = animation;
      video.loop = asset.loop;
      video.muted = true;
      if (video.src !== url) {
        video.src = url;
        video.load();
      }
      const ready = waitReady(video);
      layerReady[index] = ready;
      return ready;
    }
    async function playAnimation(animation, force = false) {
      const asset = ANIMATION_ASSETS[animation];
      if (!asset) return;
      if (!force && animation === currentAnimation) return;
      const seq = ++switchSeq;
      let index = layerAnimations.indexOf(animation);
      if (index < 0 || !layerReady[index]) {
        index = activeLayer.value === 0 ? 1 : 0;
      }
      await prepareLayer(index, animation);
      if (seq !== switchSeq) return;
      const video = videoOf(index);
      if (!video) return;
      try {
        await video.play();
      } catch (e) {
        return;
      }
      if (seq !== switchSeq) return;
      const previous = activeLayer.value;
      activeLayer.value = index;
      currentAnimation = animation;
      if (previous >= 0 && previous !== index) {
        window.setTimeout(() => {
          var _a;
          if (seq === switchSeq) (_a = videoOf(previous)) == null ? void 0 : _a.pause();
        }, 200);
      }
    }
    function onVideoEnded(index) {
      if (index !== activeLayer.value) return;
      const animation = currentAnimation;
      if (!animation) return;
      if (animation === "sleepStart") {
        void playAnimation("sleepLoop");
        return;
      }
      if (animation === "sleepEnd") {
        void playAnimation(idleAnimation());
        return;
      }
      if (state.value.sleeping) {
        void playAnimation("sleepLoop");
        return;
      }
      if (["click", "action", "success", "error", "turn"].includes(animation)) {
        void playAnimation(idleAnimation());
      }
    }
    function onVideoError(index) {
      layerAnimations[index] = null;
      layerReady[index] = null;
      if (activeLayer.value === index) {
        activeLayer.value = -1;
        currentAnimation = null;
      }
    }
    function parseMessage(raw) {
      return raw && typeof raw === "object" ? raw : {};
    }
    let audioCtx = null;
    let speechEl = null;
    function playSpeech(audio) {
      if (!(audio == null ? void 0 : audio.url)) return;
      if (!speechEl) {
        speechEl = new Audio();
        speechEl.preload = "auto";
      }
      speechEl.pause();
      speechEl.src = audio.url;
      void speechEl.play().catch(() => {
      });
    }
    let songEl = null;
    const singing = ref(false);
    const lyrics = ref([]);
    let lyricIndex = -1;
    let lyricTimer = null;
    function stopLyricTimer() {
      if (lyricTimer) {
        clearInterval(lyricTimer);
        lyricTimer = null;
      }
    }
    function startLyricTimer() {
      stopLyricTimer();
      lyricIndex = -1;
      if (lyrics.value.length === 0) return;
      lyricTimer = setInterval(() => {
        if (!songEl || songEl.paused) return;
        applyLyricAt(songEl.currentTime * 1e3);
      }, 250);
    }
    function reportSingError(stage, message, detail) {
      void aicode.overlay.postMessage({ type: "pet.singError", stage, message, detail: String(detail).slice(0, 300) }).catch(() => {
      });
    }
    function setLyrics(next) {
      lyrics.value = Array.isArray(next) ? next : [];
      lyricIndex = -1;
    }
    function applyLyricAt(nowMs) {
      let index = -1;
      for (let i = 0; i < lyrics.value.length; i += 1) {
        if (lyrics.value[i].timeMs <= nowMs) index = i;
        else break;
      }
      if (index === lyricIndex) return;
      lyricIndex = index;
      if (index < 0) return;
      bubbleText.value = lyrics.value[index].text.slice(0, 240);
      if (bubbleTimer) {
        clearTimeout(bubbleTimer);
        bubbleTimer = null;
      }
    }
    function startExternalLyrics() {
      stopLyricTimer();
      lyricIndex = -1;
      singing.value = true;
      if (lyrics.value.length === 0) {
        showBubble("♪ 正在播放");
        return;
      }
      const startedAt = Date.now();
      const lastEnd = lyrics.value[lyrics.value.length - 1].timeMs + 5e3;
      lyricTimer = setInterval(() => {
        const elapsed = Date.now() - startedAt;
        applyLyricAt(elapsed);
        if (elapsed > lastEnd) {
          stopLyricTimer();
          singing.value = false;
          bubbleText.value = "";
        }
      }, 250);
    }
    function requestAudioChunk(token, index, timeoutMs = 8e3) {
      return new Promise((resolve, reject) => {
        const key = token + ":" + index;
        const timer = setTimeout(() => {
          pendingChunks.delete(key);
          reject(new Error("拉取第 " + index + " 片超时"));
        }, timeoutMs);
        pendingChunks.set(key, { resolve, reject, timer });
        void aicode.overlay.postMessage({ type: "pet.audioChunk", token, index }).catch((error) => {
          clearTimeout(timer);
          pendingChunks.delete(key);
          reject(error);
        });
      });
    }
    const pendingChunks = /* @__PURE__ */ new Map();
    function settleAudioChunk(message) {
      const token = typeof message.token === "string" ? message.token : "";
      const index = typeof message.index === "number" ? message.index : 0;
      const waiter = pendingChunks.get(token + ":" + index);
      if (!waiter) return;
      pendingChunks.delete(token + ":" + index);
      clearTimeout(waiter.timer);
      if (typeof message.base64 === "string" && message.base64) waiter.resolve(message.base64);
      else waiter.reject(new Error(typeof message.error === "string" ? message.error : "切片为空"));
    }
    async function buildAudioUrlFromToken(token, count, mimeType) {
      const parts = [];
      for (let index = 0; index < count; index += 1) {
        const base64 = await requestAudioChunk(token, index);
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
        parts.push(bytes);
      }
      return URL.createObjectURL(new Blob(parts, { type: mimeType }));
    }
    function playSong(song) {
      var _a;
      if (!song) return;
      setLyrics(song.lyrics);
      if (song.audioToken && ((_a = song.chunkCount) != null ? _a : 0) > 0) {
        void playChunkedSong(song);
        return;
      }
      if (song.url) {
        void playDirectUrl(song.url, song.mimeType);
        return;
      }
      startExternalLyrics();
    }
    async function playDirectUrl(url, mimeType) {
      if (!songEl) {
        songEl = new Audio();
        songEl.preload = "auto";
        songEl.addEventListener("ended", () => {
          singing.value = false;
          stopLyricTimer();
          bubbleText.value = "";
        });
        songEl.addEventListener("error", () => {
          singing.value = false;
          stopLyricTimer();
        });
      }
      speechEl == null ? void 0 : speechEl.pause();
      songEl.src = url;
      singing.value = true;
      try {
        await songEl.play();
      } catch (error) {
        singing.value = false;
        stopLyricTimer();
        const message = error instanceof Error ? error.message : String(error);
        showBubble("这首唱不了：" + message);
        reportSingError("directUrl", message, url);
        return;
      }
      startLyricTimer();
    }
    let objectUrl = null;
    async function playChunkedSong(song) {
      try {
        const url = await buildAudioUrlFromToken(
          song.audioToken,
          song.chunkCount,
          song.mimeType || "audio/mpeg"
        );
        if (objectUrl) URL.revokeObjectURL(objectUrl);
        objectUrl = url;
        if (!songEl) {
          songEl = new Audio();
          songEl.preload = "auto";
          songEl.addEventListener("ended", () => {
            singing.value = false;
            stopLyricTimer();
            bubbleText.value = "";
          });
          songEl.addEventListener("error", () => {
            singing.value = false;
            stopLyricTimer();
          });
        }
        speechEl == null ? void 0 : speechEl.pause();
        songEl.src = url;
        singing.value = true;
        try {
          await songEl.play();
        } catch (error) {
          singing.value = false;
          stopLyricTimer();
          const message = error instanceof Error ? error.message : String(error);
          showBubble("需要先点一下桌宠再说唱歌：" + message);
          reportSingError("chunked", message, `chunks=${song.chunks.length} ready=${songEl.readyState}`);
          return;
        }
        void aicode.overlay.postMessage({
          type: "pet.singState",
          paused: songEl.paused,
          muted: songEl.muted,
          volume: songEl.volume,
          currentTime: songEl.currentTime,
          duration: Number.isFinite(songEl.duration) ? songEl.duration : -1,
          readyState: songEl.readyState,
          errorCode: songEl.error ? songEl.error.code : 0
        }).catch(() => {
        });
        startLyricTimer();
      } catch (error) {
        singing.value = false;
        stopLyricTimer();
        showBubble("这首唱不了：" + error.message);
      }
    }
    function stopSong() {
      if (songEl) {
        songEl.pause();
        songEl.currentTime = 0;
      }
      singing.value = false;
      stopLyricTimer();
      lyrics.value = [];
      bubbleText.value = "";
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
        objectUrl = null;
      }
    }
    async function doSing() {
      closeMenu();
      if (singing.value) {
        request("pet.stopSing");
        stopSong();
        return;
      }
      unlockAudio();
      request("pet.sing");
    }
    let audioUnlocked = false;
    let unlockEl = null;
    function unlockAudio() {
      if (audioUnlocked) return;
      try {
        if (!unlockEl) {
          unlockEl = new Audio();
          unlockEl.src = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAIlYAAESsAAACABAAZGF0YQAAAAA=";
          unlockEl.volume = 0;
        }
        void unlockEl.play().then(() => {
          audioUnlocked = true;
          unlockEl == null ? void 0 : unlockEl.pause();
        }).catch(() => {
        });
      } catch (e) {
      }
    }
    function playClickSound() {
      if (!settings.value.pet.clickSound) return;
      try {
        audioCtx = audioCtx != null ? audioCtx : new AudioContext();
        const now = audioCtx.currentTime;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.exponentialRampToValueAtTime(1320, now + 0.08);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(1e-4, now + 0.12);
        osc.connect(gain).connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.14);
      } catch (e) {
      }
    }
    function showBubble(text) {
      if (!text) return;
      if (singing.value) return;
      bubbleText.value = text.slice(0, 240);
      if (bubbleTimer) clearTimeout(bubbleTimer);
      bubbleTimer = setTimeout(() => {
        bubbleText.value = "";
        bubbleTimer = null;
      }, Math.max(1500, settings.value.bubbleDurationMs));
    }
    async function updateDragRegion() {
      const stage = stageEl.value;
      if (!stage) return;
      const rect = stage.getBoundingClientRect();
      await aicode.overlay.setDragRegion({ left: rect.left, top: rect.top, width: rect.width, height: rect.height }).catch(() => {
      });
    }
    async function applySize() {
      if (lastWidth === windowWidth.value && lastHeight === windowHeight.value) return;
      lastWidth = windowWidth.value;
      lastHeight = windowHeight.value;
      await aicode.overlay.resize(windowWidth.value, windowHeight.value).catch(() => {
      });
      await updateDragRegion();
    }
    async function syncWindowSize() {
      if (dragging.value) {
        pendingResize = true;
        return;
      }
      pendingResize = false;
      await applySize();
    }
    async function applySettings(next) {
      settings.value = normalizeSettings(next);
      await nextTick();
      await aicode.overlay.setVisibilityPolicy(settings.value.pet.alwaysOnTop ? "always" : "foreground").catch(() => {
      });
      await applySize();
      if (currentAnimation === null || !ANIMATION_ASSETS[currentAnimation]) {
        await playAnimation(state.value.sleeping ? "sleepLoop" : idleAnimation(), true);
      }
    }
    function applyState(next) {
      var _a, _b;
      const previous = state.value;
      const animationChanged = next.lastAnimation !== previous.lastAnimation;
      const textChanged = (next.lastText || "") !== (previous.lastText || "");
      const moodDropped = typeof next.mood === "number" && next.mood <= 30 && previous.mood > 30;
      state.value = {
        sleeping: next.sleeping === true,
        runActive: next.runActive === true,
        toolsActive: typeof next.toolsActive === "number" ? next.toolsActive : 0,
        mood: typeof next.mood === "number" ? next.mood : MOOD_DEFAULT,
        lastAnimation: (_a = next.lastAnimation) != null ? _a : null,
        lastText: typeof next.lastText === "string" ? next.lastText : "",
        updatedAt: typeof next.updatedAt === "number" ? next.updatedAt : Date.now()
      };
      if (textChanged && state.value.lastText) {
        const sleepLine = !state.value.sleeping || SLEEP_ANIMATIONS.includes((_b = state.value.lastAnimation) != null ? _b : "idle");
        const singingNow = singing.value;
        if (sleepLine && !singingNow) showBubble(state.value.lastText);
      }
      if (animationChanged && state.value.lastAnimation) {
        const sleeping = state.value.sleeping;
        if (!sleeping || SLEEP_ANIMATIONS.includes(state.value.lastAnimation)) {
          void playAnimation(state.value.lastAnimation, true);
        }
      } else if (moodDropped && !state.value.runActive && !state.value.sleeping) {
        void playAnimation(settings.value.animations.turn);
      }
    }
    function onMessage(raw) {
      var _a;
      const message = parseMessage(raw);
      if (message.type === "pet.settings" && message.settings) {
        void applySettings(message.settings);
      } else if (message.type === "pet.state" && message.state) {
        applyState(message.state);
      } else if (message.type === "pet.speech") {
        playSpeech(message.audio);
      } else if (message.type === "pet.sing") {
        const song = message.song;
        const lines = Array.isArray(message.lyrics) ? message.lyrics : [];
        playSong(
          song ? {
            ...song,
            lyrics: lines,
            audioToken: typeof message.audioToken === "string" ? message.audioToken : "",
            chunkCount: typeof message.chunkCount === "number" ? message.chunkCount : 0,
            mimeType: typeof message.mimeType === "string" ? message.mimeType : ""
          } : null
        );
      } else if (message.type === "pet.audioChunk") {
        settleAudioChunk(message);
      } else if (message.type === "pet.singStop") {
        stopSong();
      } else if (message.type === "click") {
        void closeMenu();
        if (state.value.sleeping) {
          showBubble("唔……我在睡觉呢。");
        } else {
          playClickSound();
          void aicode.overlay.postMessage({ type: "pet.click" }).catch(() => {
          });
        }
      } else if (message.type === "longPress") {
        void openMenu();
      } else if (message.type === "dragStart") {
        dragging.value = true;
      } else if (message.type === "dragEnd") {
        dragging.value = false;
        if (pendingResize) void syncWindowSize();
      } else if (message.type === "snap") {
        document.body.dataset.edge = String((_a = message.edge) != null ? _a : "");
      } else if (message.type === "appState" && message.foreground === true) {
        void closeMenu();
      }
    }
    async function openMenu() {
      menuOpen.value = true;
      await nextTick();
      await syncWindowSize();
    }
    async function closeMenu() {
      if (!menuOpen.value) return;
      menuOpen.value = false;
      await nextTick();
      await syncWindowSize();
    }
    function onWindowPointerDown(event) {
      var _a;
      unlockAudio();
      if (!menuOpen.value) return;
      if ((_a = event.target) == null ? void 0 : _a.closest(".menu")) return;
      void closeMenu();
    }
    function request(type, extra = {}) {
      void aicode.overlay.postMessage({ type, ...extra }).catch(() => {
      });
    }
    async function doInteract(kind) {
      void closeMenu();
      request("pet.interact", { kind });
    }
    async function toggleSleep() {
      void closeMenu();
      request("pet.toggleSleep");
    }
    async function showSettingsTip() {
      void closeMenu();
      bubbleText.value = "";
      showBubble("在「设置 → 插件 → AiCode 桌宠 → 插件配置」里修改设置。");
    }
    async function hidePet() {
      void closeMenu();
      request("pet.hide");
    }
    onMounted(async () => {
      offMessage = aicode.overlay.onMessage(onMessage);
      window.addEventListener("pointerdown", () => unlockAudio(), { passive: true });
      await applySize();
      await prepareLayer(0, settings.value.animations.idle);
      await prepareLayer(1, settings.value.animations.drag);
      void aicode.overlay.postMessage({ type: "pet.ready" }).catch(() => {
      });
    });
    onBeforeUnmount(() => {
      var _a, _b, _c, _d;
      if (offMessage) offMessage();
      if (bubbleTimer) clearTimeout(bubbleTimer);
      void (audioCtx == null ? void 0 : audioCtx.close().catch(() => {
      }));
      audioCtx = null;
      (_a = videoA.value) == null ? void 0 : _a.pause();
      (_b = videoB.value) == null ? void 0 : _b.pause();
      stopSong();
      stopLyricTimer();
      songEl = null;
      (_c = videoA.value) == null ? void 0 : _c.removeAttribute("src");
      (_d = videoB.value) == null ? void 0 : _d.removeAttribute("src");
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(
        "div",
        {
          class: normalizeClass(["pet-window", { "is-dragging": dragging.value, "is-sleeping": state.value.sleeping }]),
          style: normalizeStyle(windowStyle.value),
          onPointerdown: onWindowPointerDown
        },
        [
          createVNode(Transition, { name: "bubble" }, {
            default: withCtx(() => [
              bubbleText.value ? (openBlock(), createElementBlock(
                "div",
                {
                  key: 0,
                  class: normalizeClass(["bubble", { sleeping: state.value.sleeping }])
                },
                [
                  createElementVNode(
                    "span",
                    _hoisted_1,
                    toDisplayString(bubbleText.value),
                    1
                    /* TEXT */
                  ),
                  createElementVNode("button", {
                    class: "bubble-close",
                    type: "button",
                    "aria-label": "收起气泡",
                    onClick: _cache[0] || (_cache[0] = ($event) => bubbleText.value = "")
                  }, "×")
                ],
                2
                /* CLASS */
              )) : createCommentVNode("v-if", true)
            ]),
            _: 1
            /* STABLE */
          }),
          createElementVNode(
            "div",
            {
              ref_key: "stageEl",
              ref: stageEl,
              class: "pet-stage",
              style: normalizeStyle(stageStyle.value)
            },
            [
              createElementVNode(
                "video",
                {
                  ref_key: "videoA",
                  ref: videoA,
                  class: normalizeClass(["pet-video", { show: activeLayer.value === 0 }]),
                  muted: "",
                  playsinline: "",
                  preload: "auto",
                  onEnded: _cache[1] || (_cache[1] = ($event) => onVideoEnded(0)),
                  onError: _cache[2] || (_cache[2] = ($event) => onVideoError(0))
                },
                null,
                34
                /* CLASS, NEED_HYDRATION */
              ),
              createElementVNode(
                "video",
                {
                  ref_key: "videoB",
                  ref: videoB,
                  class: normalizeClass(["pet-video", { show: activeLayer.value === 1 }]),
                  muted: "",
                  playsinline: "",
                  preload: "auto",
                  onEnded: _cache[3] || (_cache[3] = ($event) => onVideoEnded(1)),
                  onError: _cache[4] || (_cache[4] = ($event) => onVideoError(1))
                },
                null,
                34
                /* CLASS, NEED_HYDRATION */
              ),
              activeLayer.value < 0 ? (openBlock(), createElementBlock("div", _hoisted_2, [..._cache[7] || (_cache[7] = [
                createElementVNode(
                  "span",
                  { class: "eye left" },
                  null,
                  -1
                  /* CACHED */
                ),
                createElementVNode(
                  "span",
                  { class: "eye right" },
                  null,
                  -1
                  /* CACHED */
                ),
                createElementVNode(
                  "span",
                  { class: "mouth" },
                  null,
                  -1
                  /* CACHED */
                )
              ])])) : createCommentVNode("v-if", true),
              state.value.sleeping ? (openBlock(), createElementBlock("span", _hoisted_3, "Z")) : createCommentVNode("v-if", true)
            ],
            4
            /* STYLE */
          ),
          menuOpen.value ? (openBlock(), createElementBlock(
            "div",
            {
              key: 0,
              class: "menu",
              style: normalizeStyle(menuStyle.value)
            },
            [
              createElementVNode("button", {
                type: "button",
                onClick: _cache[5] || (_cache[5] = ($event) => doInteract("headpat"))
              }, "摸头"),
              createElementVNode("button", {
                type: "button",
                onClick: _cache[6] || (_cache[6] = ($event) => doInteract("feed"))
              }, "喂食"),
              createElementVNode(
                "button",
                {
                  type: "button",
                  onClick: doSing
                },
                toDisplayString(singing.value ? "停唱" : "唱歌"),
                1
                /* TEXT */
              ),
              createElementVNode(
                "button",
                {
                  type: "button",
                  onClick: toggleSleep
                },
                toDisplayString(state.value.sleeping ? "起床" : "睡觉"),
                1
                /* TEXT */
              ),
              createElementVNode("button", {
                type: "button",
                onClick: showSettingsTip
              }, "设置"),
              createElementVNode("button", {
                type: "button",
                class: "hide",
                onClick: hidePet
              }, "隐藏")
            ],
            4
            /* STYLE */
          )) : createCommentVNode("v-if", true)
        ],
        38
        /* CLASS, STYLE, NEED_HYDRATION */
      );
    };
  }
});
const app = createApp(_sfc_main);
if (window.AicodeUI) app.use(window.AicodeUI);
app.mount("#app");
